// ===================================================================
// $Id: icbbox.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// aabb_templ.h
//    Axis alligned bounding box for irradiance caching.
//
// Class: fixvector
//
// Initial coding by Jaroslav Krivanek, March 2008.

#ifndef __ICBBOX_H__
#define __ICBBOX_H__

#include "icconf.h"
#include "icvec3.h"
#include "aabb_tmpl.h"

typedef CAABBTmpl<CICVec3> CICBBox;

#endif // __ICBBOX_H__
