// ===================================================================
// $Id: icvec3.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// CICVec3.h
//     Header file for a 3d vector for the irradiance caching lib.
//
// Class: CICVec3
//

#ifndef __CICVEC3_H__
#define __CICVEC3_H__

// ic-lib headers
#include "icconf.h"

//standard headers
#include <cmath>
#include <iostream>

/// Return the square of a number
template<class T>
T sqr(T a) { return a*a; }

/// A 3D vector utility class used throughout the ic-lib.
class CICVec3
{
public:

  /// Type for components of the vector.
  typedef float comp_type;

  /// Vector components.
  union {
    struct { comp_type x, y, z;};
    comp_type v[3];
  };

  /// @name Constructors.
  //@{
  CICVec3() { }
  CICVec3(float  X, float  Y, float  Z) { x = X; y = Y; z = Z; }
  CICVec3(float  X) { x = y = z = X; }
  CICVec3(const CICVec3 &v) { x = v.x; y = v.y; z = v.z; }
  //@}

  // @name Set vector components.
  //@{
  void Set(const float  &a, const float  &b, const float  &c) {x=a; y=b; z=c;}
  void Set(const float  &a) { x=y=z=a; }
  //@}

  /// @name Access to vector components.
  //@{
  float& operator[] (unsigned int idx) {return operator[] ((int)idx);}
  float& operator[] (int idx) { return v[idx]; }
  const float& operator[] (unsigned int idx) const {return operator[] ((int)idx);}
  const float& operator[] (int idx) const { return v[idx]; }
  //@}

  // Normalize the vector.
  inline void Normalize();
 
  /// Return an arbitrary normal to `v'.
  /**
     The function tries v x (0,0,1) an if the result is too small,
     it returns does v x (0,1,0).

     @param v (in) The vector we want to find normal for.
     @return The normal vector to v.
  */
  friend inline CICVec3 ArbitraryNormal(const CICVec3 &v); 

  /**
    @brief Find a right handed coordinate system with (*this) being
    the z-axis. 
    
    For a right-handed system, U x V = (*this) holds.
    This implementation is here to avoid inconsistence and confusion
    when construction coordinate systems using ArbitraryNormal():
    In fact:
      - V = ArbitraryNormal(N);
      - U = CrossProd(V,N);
    .
    constructs a right-handed coordinate system as well, BUT:
      -# bugs can be introduced if one mistakenly constructs a 
        left handed sytems e.g. by doing
         - U = ArbitraryNormal(N);
         - V = CrossProd(U,N);
      -# this implementation gives non-negative base vectors
       for (*this)==(0,0,1) |  (0,1,0) | (1,0,0), which is
       good for debugging and is not the case with the implementation
       using ArbitraryNormal()
  */
  void RightHandedBase(CICVec3& U, CICVec3& V) const;

  /// Transforms a vector to the global coordinate frame.
  /**
    Given a local coordinate frame (U,V,N) (i.e. U,V,N are 
    the x,y,z axes of the local coordinate system) and
    a vector 'loc' in the local coordiante system, this
    function returns a the coordinates of the same vector
    in global frame (i.e. frame (1,0,0), (0,1,0), (0,0,1)).
  */
  friend inline CICVec3 ToGlobalFrame(const CICVec3& loc,
	  const CICVec3& U,
	  const CICVec3& V,
	  const CICVec3& N);
  
  /// Transforms a vector to a local coordinate frame.
  /**
    Given a local coordinate frame (U,V,N) (i.e. U,V,N are 
    the x,y,z axes of the local coordinate system) and
    a vector 'loc' in the global coordiante system, this
    function returns a the coordinates of the same vector
    in the local frame.
  */
  friend inline CICVec3 ToLocalFrame(const CICVec3& loc,
	  const CICVec3& U,
	  const CICVec3& V,
	  const CICVec3& N);

  /// the magnitude=size of the vector
  friend inline float Magnitude(const CICVec3 &v);
  /// the squared magnitude of the vector .. for efficiency in some cases
  friend inline float SqrMagnitude(const CICVec3 &v);
  /// Magnitude(v1-v2)
  friend inline float Distance(const CICVec3 &v1, const CICVec3 &v2);
  /// SqrMagnitude(v1-v2)
  friend inline float SqrDistance(const CICVec3 &v1, const CICVec3 &v2);

  // creates the vector of unit size corresponding to given vector
  friend inline CICVec3 Normalize(const CICVec3 &A);
  friend inline CICVec3 SafeNormalize(const CICVec3 &A);

  // is the point inside a given CICBBox?
  bool IsInsideBox(const CICVec3 &bmin,const CICVec3 &bmax)const
  {
    return 
      x>=bmin.x && x<=bmax.x &&
      y>=bmin.y && y<=bmax.y &&
      z>=bmin.z && z<=bmax.z;
  }

  // Unary operators
  CICVec3 operator+ () const;
  CICVec3 operator- () const;

  // Assignment operators
  CICVec3& operator+= (const CICVec3 &A);
  CICVec3& operator-= (const CICVec3 &A);
  CICVec3& operator*= (const CICVec3 &A);
  CICVec3& operator*= (float A);
  CICVec3& operator/= (float A);

  // Binary operators
  friend inline CICVec3 operator+ (const CICVec3 &A, const CICVec3 &B);
  friend inline CICVec3 operator- (const CICVec3 &A, const CICVec3 &B);
  friend inline CICVec3 operator* (const CICVec3 &A, const CICVec3 &B);
  friend inline CICVec3 operator* (const CICVec3 &A, float B);
  friend inline CICVec3 operator* (float A, const CICVec3 &B);
  // friend CICVec3 operator* (const CMatrix4 &, const CICVec3 &);
  friend inline CICVec3 operator/ (const CICVec3 &A, const CICVec3 &B);

  friend inline int operator< (const CICVec3 &A, const CICVec3 &B);
  friend inline int operator<= (const CICVec3 &A, const CICVec3 &B);

  friend inline CICVec3 operator/ (const CICVec3 &A, float B);
  friend inline int operator== (const CICVec3 &A, const CICVec3 &B);
  friend inline int operator!= (const CICVec3 &A, const CICVec3 &B);
  friend inline float DotProd(const CICVec3 &A, const CICVec3 &B);
  friend inline CICVec3 CrossProd (const CICVec3 &A, const CICVec3 &B);

  friend std::ostream& operator<< (std::ostream &s, const CICVec3 &A);
  friend std::istream& operator>> (std::istream &s, CICVec3 &A);
    
  void  Minimize(const CICVec3 &p)
  {
    if (p.x < x) x = p.x;
    if (p.y < y) y = p.y;
    if (p.z < z) z = p.z;
  }

  void Maximize(const CICVec3 &p)
  {
    if (p.x > x) x = p.x;
    if (p.y > y) y = p.y;
    if (p.z > z) z = p.z;
  }

  friend inline int EpsilonEqualV3(const CICVec3 &v1, const CICVec3 &v2, float thr);

  inline float MaxComponent(void) const 
  { return (x > y) ? ( (x > z) ? x : z) : ( (y > z) ? y : z); }
};

inline CICVec3
ArbitraryNormal(const CICVec3 &N)
{
  float dist2 = N.x * N.x + N.y * N.y;
  if (dist2 > 0.0001) {
    float inv_size = 1.0f/sqrtf(dist2);
    return CICVec3(N.y * inv_size, -N.x * inv_size, 0); // N x (0,0,1)
  }
  float inv_size = 1.0f/sqrtf(N.z * N.z + N.x * N.x);
  return CICVec3(-N.z * inv_size, 0, N.x * inv_size); // N x (0,1,0)
}


inline CICVec3
ToGlobalFrame(const CICVec3 &loc,
	      const CICVec3 &U,
	      const CICVec3 &V,
	      const CICVec3 &N)
{
  return loc.x * U + loc.y * V + loc.z * N;
}

inline CICVec3
ToLocalFrame(const CICVec3 &loc,
	     const CICVec3 &U,
	     const CICVec3 &V,
	     const CICVec3 &N)
{
  return CICVec3( loc.x * U.x + loc.y * U.y + loc.z * U.z,
		    loc.x * V.x + loc.y * V.y + loc.z * V.z,
		    loc.x * N.x + loc.y * N.y + loc.z * N.z);
}

inline float
Magnitude(const CICVec3 &v) 
{
  return sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}

inline float
SqrMagnitude(const CICVec3 &v) 
{
  return v.x * v.x + v.y * v.y + v.z * v.z;
}

inline float
Distance(const CICVec3 &v1, const CICVec3 &v2)
{
  return sqrt(sqr(v1.x - v2.x) + sqr(v1.y - v2.y) + sqr(v1.z - v2.z));
}

inline float
SqrDistance(const CICVec3 &v1, const CICVec3 &v2)
{
  return sqr(v1.x-v2.x)+sqr(v1.y-v2.y)+sqr(v1.z-v2.z);
}

inline CICVec3
Normalize(const CICVec3 &A)
{
  return A * (1.0f/Magnitude(A));
}

inline CICVec3
SafeNormalize(const CICVec3 &A)
{
  float len2 = SqrMagnitude(A);
  if(len2>1e-12)
    return A * (1.0f/sqrtf(len2));
  else
    return A;
}



inline float
DotProd(const CICVec3 &A, const CICVec3 &B)
{
  return A.x * B.x + A.y * B.y + A.z * B.z;
}

inline CICVec3
CICVec3::operator+() const
{
  return *this;
}

inline CICVec3
CICVec3::operator-() const
{
  return CICVec3(-x, -y, -z);
}

inline CICVec3&
CICVec3::operator+=(const CICVec3 &A)
{
  x += A.x;  y += A.y;  z += A.z;
  return *this;
}

inline CICVec3&
CICVec3::operator-=(const CICVec3 &A)
{
  x -= A.x;  y -= A.y;  z -= A.z;
  return *this;
}

inline CICVec3&
CICVec3::operator*= (float A)
{
  x *= A;  y *= A;  z *= A;
  return *this;
}

inline CICVec3&
CICVec3::operator/=(float A)
{
  float a = 1.0f/A;
  x *= a;  y *= a;  z *= a;
  return *this;
}

inline CICVec3&
CICVec3::operator*= (const CICVec3 &A)
{
  x *= A.x;  y *= A.y;  z *= A.z;
  return *this;
}

inline CICVec3
operator+ (const CICVec3 &A, const CICVec3 &B)
{
  return CICVec3(A.x + B.x, A.y + B.y, A.z + B.z);
}

inline CICVec3
operator- (const CICVec3 &A, const CICVec3 &B)
{
  return CICVec3(A.x - B.x, A.y - B.y, A.z - B.z);
}

inline CICVec3
operator* (const CICVec3 &A, const CICVec3 &B)
{
  return CICVec3(A.x * B.x, A.y * B.y, A.z * B.z);
}

inline CICVec3
operator* (const CICVec3 &A, float B)
{
  return CICVec3(A.x * B, A.y * B, A.z * B);
}

inline CICVec3
operator* (float A, const CICVec3 &B)
{
  return CICVec3(B.x * A, B.y * A, B.z * A);
}

inline CICVec3
operator/ (const CICVec3 &A, const CICVec3 &B)
{
  return CICVec3(A.x / B.x, A.y / B.y, A.z / B.z);
}

inline CICVec3
operator/ (const CICVec3 &A, float B)
{
  float b = 1.0f / B;
  return CICVec3(A.x * b, A.y * b, A.z * b);
}

inline int
operator< (const CICVec3 &A, const CICVec3 &B)
{
  return A.x < B.x && A.y < B.y && A.z < B.z;
}

inline int
operator<= (const CICVec3 &A, const CICVec3 &B)
{
  return A.x <= B.x && A.y <= B.y && A.z <= B.z;
}

// Might replace floating-point == with comparisons of
// magnitudes, if needed.
inline int operator== (const CICVec3 &A, const CICVec3 &B)
{
  return (A.x == B.x) && (A.y == B.y) && (A.z == B.z);
}

inline int operator!= (const CICVec3 &A, const CICVec3 &B)
{
  return !(A==B);
}

inline CICVec3
CrossProd (const CICVec3 &A, const CICVec3 &B)
{
  return CICVec3(A.y * B.z - A.z * B.y,
		   A.z * B.x - A.x * B.z,
		   A.x * B.y - A.y * B.x);
}

inline void
CICVec3::Normalize()
{
  float sqrmag = x * x + y * y + z * z;
  if (sqrmag > 0.0)
    (*this) *= 1.0f / sqrtf(sqrmag);
}

// Overload << operator for C++-style output
inline std::ostream&
operator<< (std::ostream &s, const CICVec3 &A)
{
  return s << "(" << A.x << ", " << A.y << ", " << A.z << ")";
}

// Overload >> operator for C++-style input
inline std::istream&
operator>> (std::istream &s, CICVec3 &A)
{
  char a;
  // read "(x, y, z)"
  return s >> a >> A.x >> a >> A.y >> a >> A.z >> a;
}

inline int
EpsilonEqualV3(const CICVec3 &v1, const CICVec3 &v2, float thr)
{
  if ( fabs(v1.x-v2.x) > thr )
    return false;
  if ( fabs(v1.y-v2.y) > thr )
    return false;
  if ( fabs(v1.z-v2.z) > thr )
    return false;
  return true;
}

#endif // __VECTOR3_H__
