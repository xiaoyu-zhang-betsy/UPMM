// ===================================================================
// $Id: ictreebase.cpp,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// Initial coding by Jaroslav Krivanek (march 2008).

#include "icconf.h"
#include "ictreebase.h"
#include "icrec.h"

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
CICTreeBase<TRecord>::CICTreeBase(const typename CICTreeBase<TRecord>::CConstructParams& p)
{
  SetA(0.25f);
  ResetStats();
  _numThreads = (p.numThreads>=1) ? p.numThreads : 1;
  _rwLockInit(p.numThreads);
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
#ifdef IC_PTHREADS
template<class TRecord>
void
CICTreeBase<TRecord>::_rwLockInit(int numthreads) 
{
  if(numthreads<=1)
    _rwlockok = false;
  else 
  {
    _rwlockok = (pthread_rwlock_init(&_rwlock, NULL)==0);
    if(!_rwlockok) { icMsgDebug("[%s]  Error creating R/W lock", IC_NODE_NAME); }
  }
}
#endif

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
// explicit instantiation of CICTreeBase for TRecord=CICRecord
template class CICTreeBase<CICRecord>;
