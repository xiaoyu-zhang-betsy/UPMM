// ===================================================================
// $Id: iccontrib.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// iccontrib.h
//   Array of irradiance contributions to a point.
//
// Initial coding by Jaroslav Krivanek (November 2007).

#ifndef __ICCONTRIB_H__
#define __ICCONTRIB_H__

#include "icconf.h"
#include "icvec3.h"
#include "tricol.h"
#include "fixvec.h"

/// Contribution of an (ir)radiance record to a point.
template<class TRecord>
class CRecordContrib 
{
public: // methods

  /// void constructor
  CRecordContrib() {}
  CRecordContrib(TRecord *r): rec(r) {}
  CRecordContrib(TRecord *r,float weight) : rec(r),w(weight) {}

  /// Return the irradiance contribution
  const CTriCol& GetE() const {return _E; }
  /// Set the irradiance contribution from an array of floats or doubles
  template<class T> void SetE(const T* x) { _E.Set(x); /*SetEValid();*/ }
  /// Set the irradiance contribution from an rgb color
  void SetE(const CTriCol& x) { _E = x; /*SetEValid();*/ }

  /// Following is for uniform access through pointer or reference.
  /// It is used in some template functions which might either accept
  /// pointer or reference to CRecordContrib.
  //@{
  TRecord*& Rec() {return rec;}
  TRecord*const& Rec() const {return rec;}
  friend TRecord*& Rec(CRecordContrib &c) {return c.rec;}
  friend TRecord*const& Rec(const CRecordContrib &c) {return c.rec;}
  friend TRecord*& Rec(CRecordContrib *c) {return c->rec;}
  friend TRecord*const& Rec(const CRecordContrib *c) {return c->rec;}

  friend void SetE(CRecordContrib &c,const CTriCol &E){return c.SetE(E);}
  friend void SetE(CRecordContrib *c,const CTriCol &E){return c->SetE(E);}
  friend const CTriCol& GetE(const CRecordContrib &c) {return c.GetE();}
  friend const CTriCol& GetE(const CRecordContrib *c) {return c->GetE();}

  float& W() {return w;}
  const float& W() const {return w;}
  friend float& W(CRecordContrib &c) {return c.w;}
  friend const float& W(const CRecordContrib &c) {return c.w;}
  friend float& W(CRecordContrib *c) {return c->w;}
  friend const float& W(const CRecordContrib *c) {return c->w;}
  //@}

public: // data 

  /// Contributing record
  TRecord  *rec;
  /// Contribution weight
  float     w;

protected: // data
  /// Extrapolated irradiance, before multiplication by the weight.
  CTriCol  _E;

};

/// Contribution of an irradiance record to a point.
class CICRecord;
typedef CRecordContrib<CICRecord> CICContrib;


/// Array of irradiance contributions to a point.
template<class TRecord>
class CRecordContribArray : public fixvector< CRecordContrib<TRecord>, 100> {
  typedef fixvector< CRecordContrib<TRecord>, 100> super;
public:

  /// Default constructor does nothing.
  CRecordContribArray() {}

  /// Sums the weight and irradiance constributions
  inline void Sum(float &sumWeight, CTriCol &sumE) const;

  /// Sums the weight, irradiance constributions, and reciprocal HMDs
  inline void SumInvUR(float &sumWeight, CTriCol &sumE, float &sumUR) const;

  /// Sums the weight, irradiance constributions, and minimum of mindistances
  inline void SumMinUR(float &sumWeight, CTriCol &sumE, float &sumUR) const;

  /// Compute the weighted average of irradiances.
  /** 
     @return false if the array is empty. In such case 'E' is left unchanged.
   */
  inline bool WeightedAverage(float *E) const;
};

typedef CRecordContribArray<CICRecord> CICContribArray;

// --------------------------------------------------------------------------
//  CRecordContribArray::Sum()
// --------------------------------------------------------------------------
template<class TRecord>
inline void 
CRecordContribArray<TRecord>::Sum(float &sumWeight, CTriCol &sumE) const
{
  // const_iterator iend = end();
  for(typename super::const_iterator i=CRecordContribArray<TRecord>::begin();
      i != CRecordContribArray<TRecord>::end(); i++) {
    sumWeight += i->w;
    sumE      += i->w * i->GetE();
  }
}

// --------------------------------------------------------------------------
//  CRecordContribArray::SumInvUR()
// --------------------------------------------------------------------------
template<class TRecord>
inline void 
CRecordContribArray<TRecord>::SumInvUR(float &sumWeight, CTriCol &sumE, float &sumUR) const
{
  for(typename super::const_iterator i=CRecordContribArray<TRecord>::begin();
      i != CRecordContribArray<TRecord>::end(); i++) {
    sumWeight += i->w;
    sumE += i->w * i->GetE();
    sumUR += 1.0/i->Rec()->GetUnclampedR();
    sumUR = min(sumUR, i->Rec()->GetUnclampedR());
  }
}

// --------------------------------------------------------------------------
//  CRecordContribArray::SumMinUR()
// --------------------------------------------------------------------------
template<class TRecord>
inline void 
CRecordContribArray<TRecord>::SumMinUR(float &sumWeight, CTriCol &sumE, float &sumUR) const
{
  for(typename super::const_iterator i=CRecordContribArray<TRecord>::begin();
      i != CRecordContribArray<TRecord>::end(); i++) {
    sumWeight += i->w;
    sumE += i->w * i->GetE();
    sumUR = min(sumUR, i->Rec()->GetUnclampedR());
  }
}


// --------------------------------------------------------------------------
//  CRecordContribArray::WeightedAverage()
// --------------------------------------------------------------------------
template<class TRecord>
inline bool
CRecordContribArray<TRecord>::WeightedAverage(float *E) const
{
  switch(CRecordContribArray<TRecord>::size()) {
  case 0: 
    return false;
  case 1:
    CRecordContribArray<TRecord>::front().GetE().CopyData(E);
    return true;
  default:
    CTriCol sumE(0.0);
    float  sumW(0.0);
    Sum(sumW,sumE);
    sumE /= sumW;
    sumE.CopyData(E);
    return true;
  }
}

// --------------------------------------------------------------------------
//  SumContributions()
// --------------------------------------------------------------------------
template<class T>
inline void 
SumContributions(const T& clist, float &sumWeight, CTriCol &sumE)
{
  // const_iterator iend = end();
  for(typename T::const_iterator it=clist.begin(); it!=clist.end(); it++) {
    sumWeight += W(*it);
    sumE += W(*it) * GetE(*it);
  }
}

// --------------------------------------------------------------------------
//  SumValidContributions()
// --------------------------------------------------------------------------
template<class T>
inline void 
SumValidContributions(const T& clist, float &sumWeight, CTriCol &sumE)
{
  // const_iterator iend = end();
  for(typename T::const_iterator it=clist.begin(); it!=clist.end(); it++) {
    if(!IsInvalid(*it)) {
      sumWeight += W(*it);
      sumE += W(*it) * GetE(*it);
    }
  }
}

// --------------------------------------------------------------------------
//  ExtrapolateE()
// --------------------------------------------------------------------------
template<class ItT>
inline void 
ExtrapolateE(ItT first,ItT last,const CICVec3 &P,const CICVec3 &N)
{
  CTriCol E;
  for( ; first != last ; ++first) {
    if(!IsEValid(*first)) {
      Rec(*first)->ExtrapolateIrradiance(P,N,E.data());
      SetE(*first,E);
    }
  }
}

#endif // __ICCONTRIB_H__
