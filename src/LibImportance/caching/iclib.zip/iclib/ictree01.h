// ===================================================================
// $Id: ictree01.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// icoctree.h
//  Header file for the irradiance cache octree. Based on PBRT implementation.
//
// Initial coding by Jaroslav Krivanek (Nov 2007).

#ifndef __ICTREE01_H__
#define __ICTREE01_H__

#include "icconf.h"
#include "ictreebase.h"
#include "iccontrib.h"
#include "fixvec.h"

/// Octree for (ir)radiance cache based on Matt Pharr's code in PBRT.
/**
  This octree implementation is based on Matt Pharr's code in PBRT. 
  One record can be referenced by several octree nodes.
  Tree lookup only follows a single path in the tree => simpler & faster traversal.
  In addition, shrinking of a record's radius is possible without having to 
  move the record in the tree.
*/
template<class TRecord>
class CICOctree01 : public CICTreeBase<TRecord>
{
public:  // types

  // @@@ FIXME TODO There must be a more intelligent way to inherit types 
  // defined in the parent class (MSVC does it automatically, but gcc does not)
  typedef typename CICTreeBase<TRecord>::CRecordList  CRecordList;
  typedef typename CICTreeBase<TRecord>::CConstructParams  CConstructParams;

  /// Node of the (ir)radiance cache octree.
  class CNode
  {
  public:

    /// Constructor resets the children.
    CNode (const CICVec3& a_boxCenter, const float a_halfSideLen)
      : halfSideLen(a_halfSideLen), boxCenter(a_boxCenter) {
      for (int i=0; i<8; i++) children[i] = 0;
    }

    /// Destructor destructs all descendants.
    ~CNode();

    /// Return the i-th son. If it does not exist, it is created.
    CNode* GetSonAlloc(int a_i,const CICVec3& a_boxCenter,const float a_halfSideLen)
    {
      if (!children[a_i]) children[a_i] = new CNode(a_boxCenter,a_halfSideLen);
      return children[a_i];
    }

    /// Return node's bounding box.
    CICBBox GetBBox() const { return CICBBox(boxCenter,halfSideLen); }

  public:
    /// List of records in this node.
    CRecordList  recList;
    /// Array of pointers to eight sons.
    CNode*       children[8];
    /// Half the side length of the octree node.
    float        halfSideLen;
    /// Center of the octree node box.
    CICVec3      boxCenter;
  };

  /// Wrapper class to identify location of a record in the octree.
  /** 
      This class is intended for functions that may need to shrink records' radius
      and consequently move the record in the tree. However, this octree implementation 
      does not need to move records when radius is decreased, so the structure only 
      contains a record pointer.
    */
  class CTreeLoc
  {
  public: // data
    /// Record pointer.
    TRecord  *rec;
    /// Return the record pointer.
    TRecord  *GetObj() { return rec; }
    /// Return the record pointer.
    const TRecord *GetObj() const { return rec; }
  };

  /// Array of records' location the tree. 
  /** Fixed array of length 100 is used in order to avoid memory allocations. */
  class CTreeLocArray : public fixvector< CTreeLoc, 100 > { };

public: // methods

  /// Constructor builds the root node.
  CICOctree01 (const CConstructParams& params);

  /// De-allocates all the octree nodes and irradiance cache records.
  ~CICOctree01 ();

  /// Clear the cache contents.
  void Clear ();

  /// Insert a new record in the cache.
  /** @return true on error, false if ok */
  bool InsertRecord(TRecord *rec);
   
  /// Get records that contribute to interpolation at a given point.
  /**
     @param P (in) Query point.
     @param N (in) Surface (shading) normal at P.
     @param tid (in) Thread ID (currently unused, intended for thread-specific caching).
     @param carray (out) List of records that contribute to the query point.
       
     @return 'false' if no usable record is found in the cache
  */
  bool GetContributions(
    const CICVec3   &P,
    const CICVec3   &N,
    const int       tid,
    CRecordContribArray<TRecord> &carray) const;

  /// Return true, if interpolation is possible at (P,N)
  bool HasContribution(const CICVec3 &P,const CICVec3 &N) const;

  /// Find records within a given distance from a given point.
  /**
     A record is considered only if the dot product of its 
     normal and a given normal is greater than @ref IC_MIN_ALLOWED_DOT.
     @return The number of records found. Records are pushed back to the
      array 'larray' (larray is not cleared at the beginning).
    */
  int FindInRange(const CICVec3& P, const CICVec3& N, float R, CTreeLocArray &larray) const;

  /// Find all records having a given point in their influence area.
  /** 
    This query finds those records ri = {Pi, Ni, Ri} for which:
     -#  N . Ni <= @ref IC_MIN_ALLOWED_DOT
     -# ||P-Pi|| <= @ref _a * Ri + Radd
    
    Records are stored in the list specified by the 'larray' parameter.
    
    NOTICE: In the current implementation, a record can appear in larray multiple 
    times!!!
   */
  int FindInInfluenceArea(const CICVec3 &P, const CICVec3 &N, float Radd, CTreeLocArray &larray) const;

  /// Decreases the radius of a record.
  /** No tree update for this octree (the tree remains valid if a radius of a 
      record is decreased). */
  inline void DecreaseRadius(const CTreeLoc &tloc, float newR, bool updateOctree)
  { if( newR < tloc.rec->GetR() ) { tloc.rec->SetR(newR); this->_stats.numDecreaseR ++; } }

protected:
 
  /// Compute bouding cube and create the octree root.
  void _setupRoot(const CICBBox& bbox);

  /// Enlarge the tree bounding box to accomodate a new record.
  /** 
      The octree is blown up so that the root node contains the entire 
      bounding box of the node being added (not only its center).
     @return true on error, false if OK. 
   */
  bool _enlargeBBox(TRecord *rec);

  /// Recursive portion of _insertRecord().
  void  _insertRecursive(
    CNode *node, const CICBBox &nodeBound,
    TRecord *dataItem, const CICBBox &dataBound,
    float diag2, int depth);

  /// Store a record in the given octree node.
  inline void _storeInNode(CNode *node, TRecord *rec)
  { node->recList.push_back(rec); }

protected: // data
  
  /// Root of the octree.
  CNode *_root;

  /// Item on a octree traversal stack.
  class CTraversalStackEntry {   
  public:
    const CNode *node;
    void Set(const CNode *n) { node=n; }
  };

};

#endif //  __ICTREE01_H__
