// ===================================================================
// $Id: icache.h,v 1.2 2010/02/25 17:51:02 jaroslav Exp $
//
// icache.h
//     Encapsulation of the irradiance caching scheme.
//
// Class: CICache
//
// Initial coding by Jaroslav Krivanek, Nov 2007.

#ifndef __ICACHE_H__
#define __ICACHE_H__

// ic-lib headers
#include "icconf.h"
#include "icbase.h"

// forward declarations
class CICSampler;

/// Encapsulation of the irradiance caching algorithm.
class CICache : public CCachingBase<CICRecord>
{
public: // data types

  /// Class holding constructor parameters for the CICache class.
  class CConstructParams : public CCachingBase<CICRecord>::CConstructParams {
  public:
    /// Pointer to a diffuse hemisphere sampler implementation.
    /** Hemisphere sampler is used to compute new irradiance value when 
        interpolation cannot be used. */
    CICSampler* icSampler;
    /// Cache file name.
    const char *filename;
    /// File mode for cacing.
    const char *filemode;
    /// Empty default constructor.
    CConstructParams() {}
  };

public:    // methods
  
  /// Constructor. 
  CICache(class CConstructParams& p):CCachingBase<CICRecord>(p),
    _icSampler(p.icSampler),
    _filename (p.filename ? p.filename : ""),
    _filemode (p.filemode ? p.filemode : "")
  {
    assert( p.icSampler != 0);
    if(_filemode.c_str()[0]=='R')
      SetCachingMode(CICMode::EE_AlwaysRead);
    _numRecordsRead = 0;
  }

  /// Irradince cache query: Return irradiance at a given point.
  /**  
    @param P (in) Query location.
    @param N (in) Shading normal at P, possibly bumped.
    @param Ng (in) Shading normal at P, no bump applied. 
    @param footprintArea (in) Area of the pixel projected to P.
    @param shadingGeometry (in) Pointer to the renderer specific structure holding
           the information about the hit point at P. This pointer is simply passed 
           to the hemisphere sampler (if a new record is created).
    @param numRays (in) Number of rays to be used for hemisphere sampling 
           (if a new record is created).
    @param tid (in) Thread ID of the current thread.
    @param outAvgDirL (out) Average direction of incoming luminance.
    @param outAvgDirR (out) Average direction of incoming red radiance.
    @param outAvgDirG (out) Average direction of incoming green radiance.
    @param outAvgDirB (out) Average direction of incoming blue radiance.
    @param outE (out)  Computed irradiance value at P.    
  */
  EQueryResult GetIrradiance(
    const CICVec3    &P,
    const CICVec3    &N,
    const CICVec3    &Ng,
    const float      footprintArea,
    const void       *shadingGeometry,
	void             *data,
    const int        numRays,
    const int        tid,
    CICVec3          &outAvgDirL,
    CICVec3          &outAvgDirR,
    CICVec3          &outAvgDirG,
    CICVec3          &outAvgDirB, 
    float            outE[3]);

  /// Interpolate irradiance at a given point.
  /**
    @param P (in) Query location.
    @param N (in) Shading normal at P, possibly bumped.
    @param Ng (in) Shading normal at P, no bump applied. 
    @param tid (in)  Thread ID.
    @param outAvgDirL (out) Average direction of incoming luminance.
    @param outAvgDirR (out) Average direction of incoming red radiance.
    @param outAvgDirG (out) Average direction of incoming green radiance.
    @param outAvgDirB (out) Average direction of incoming blue radiance.
    @param outE (out)  Interpolated irradiance value at P.    

    @return 
      - 'false' if no usable irradiance record is found in the cache
        (the primary method - i.e. hemisphere sampling - is required).
      - 'true' if at least one record was found and irradiance data has been set 
        to 'outE' parameter.
  */
  EQueryResult InterpolateIrradiance(
    const CICVec3  &P,
    const CICVec3  &N,
    const CICVec3  &Ng,
    const int      tid,
    CICVec3        &outAvgDirL,
    CICVec3        &outAvgDirR,
    CICVec3        &outAvgDirG,
    CICVec3        &outAvgDirB, 
    float          outE[3]) const;

  /// Computes and adds a new irradiance record at the specified position.
  /**
     This method perform all the various heuristics for setting record radius
     and capping the gradients. For parameters, see GetIrradiance().
    */
  EQueryResult AddIrradiance(
    const CICVec3    &P,
    const CICVec3    &N,
    const CICVec3    &Ng,
    const float      footprintArea,
    const void       *shadingGeometry,
    int              numRays,
    CICVec3          &outAvgDirL,
    CICVec3          &outAvgDirR,
    CICVec3          &outAvgDirG,
    CICVec3          &outAvgDirB, 
    float            outE[3],
    CICRecord        **newRec,
	void             *data);

  /// Set all irradiance values in the cache to a random value.
  /** Only for debugging purposes (visualize cache contents). */
  void RandomizeIrradiances();
  /// Return a pointer to the diffuse sampler.
  CICSampler* GetSampler()             {return _icSampler;}
  /// Return a const pointer to the diffuse sampler.
  const CICSampler* GetSampler() const {return _icSampler;}

  /// Read in cache contents from a file.
  /**
    This function first checks if a file name was specified and if 
    reading is requested by the current file mode.
    If these checks pass, a file is open and ReadCache(FILE*) is
    called to actually read in the cache contents.

    @return 
       - true  on error
       - false on success (no reading required or reading suceeded)
   */
  bool ReadCache();

  /// Read cache contents from the given stream and insert then in the octree.
  /** @return true on error, false on success */
  bool ReadCache(FILE *f);

  /// Write out cache to a file.
  /**
    This function first checks if any filename was specified and if 
    writing is requested by the current filemode.

    In the "w" mode, the file is overwritten with the current cache contents.
    In the "rw" mode, the cache contents are merged with an existing file (if exists).

    @return 
       - true  on error
       - false on success (no writing required or writing suceeded)
   */
  bool WriteCache();

  /// Write all the records in the cache to the given stream.
  /** @return true on error, false on success */
  bool WriteCache(FILE *f);

  /// Return the number of records read from the file
  size_t GetNumRecordsRead() const { return _numRecordsRead; }

  /// Return the current filename for reading/writing cache contents.
  const std::string& GetFileName() const { return _filename; }
  /// Return the current filemode for reading/writing cache contents.
  const std::string& GetFileMode() const { return _filemode; }

protected: // methods

  /// Read record from a stream.
  /** @return true on error, false on success */
  bool _readRecord(CICRecord *rec, FILE *f);

  /// Write a record to a stream.
  /** @return true on error, false on success */
  bool _writeRecord(const CICRecord *rec, FILE *f);

protected: // data

  /// Diffuse sampler for hemisphere sampling 
  /** Use to compute a new irradiance value when interpolation cannot be used. */
  CICSampler* _icSampler;

  /// Number of records read from the file
  size_t _numRecordsRead;
  /// Filename for reading/writing cache contents.
  const std::string _filename;
  /// Cache behavior concerning reading/writing from/to file.
  const std::string _filemode;
};

#endif // __ICACHE_H__
