// ===================================================================
// $Id: ictreebase.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// ictreebase.h
//
// Initial coding by Jaroslav Krivanek (March 2008).

#ifndef __ICTREEBASE_H__
#define __ICTREEBASE_H__

#include "icconf.h"
#include "icbbox.h"

// standard headers
#include <vector>

#ifdef IC_PTHREADS 
#include <pthread.h>
#endif

/** 
   @brief Functionality common to all spatial data structure implementations used 
   to index cache records.
 */
template<class TRecord>
class CICTreeBase
{
public:  // types

  /// List of cache records.
  class CRecordList : public std::vector<TRecord*>  { };

  /// Type used for event counters.
  typedef long long counter_t;

  /// Structure holding constructor parameters for the tree.
  class CConstructParams {
  public:
    /// Scene bounding box.
    CICBBox bbox;
    /// Number of threads.
    int numThreads;

    /// Empty default constructor.
    CConstructParams() {numThreads=1;}
  };

  /// Constructor allocates the threading support.
  CICTreeBase (const CConstructParams& params);

  /// Return constant linear list of cached records.
  const CRecordList& GetRecordList() const { return _linList; }
  /// Return mutable linear list of cached records.
  CRecordList& GetRecordList() { return _linList; }

  /// Return the value of the allowed caching error.
  float GetA() const { return _a;}
  /// Set the value of the allowed caching error.
  void  SetA(const float a) { _a = std::max<float>(a,0.0001f); }

  /// @name Caching statistics access.
  //@{
  /// Return the number of irradiance records in the cache.
  size_t GetNumRecords() const { return _linList.size(); }
  /// Return the number of successful queries (i.e. irradiance was interpolated).
  counter_t GetNumQueriesSuc() const { return _stats.numQueriesSuc; }
  /// Return the number of unsuccessful queries (i.e. new irradiance value was computed).
  counter_t GetNumQueriesFail() const { return _stats.numQueriesFail; }
  /// Return the number of weight calculations with zero response.
  counter_t GetNumWeightZero() const { return _stats.numWeightZero; }
  /// Return the number of weight calculations with nonzero response.
  counter_t GetNumWeightNonzero() const { return _stats.numWeightNonzero; }
  /// Return the number of times a record's radius was decreased (due to neighbor clamping).
  counter_t GetNumDecreaseR() const { return _stats.numDecreaseR; }
  /// Return the number of times a record was moved in octree (because of the change of the record's radius).
  counter_t GetNumMoveInOctree() const { return _stats.numMoveInOctree; }
  /// Sets all statistics values to zero.
  void ResetStats(void) { memset(&_stats, 0, sizeof(_stats)); }
  //@}

  /// Return the bounding box of a record 
  /** Depends on the current allowed caching error. */
  inline CICBBox GetRecBBox(const TRecord *rec)
  {
    return CICBBox(rec->GetP(),rec->GetValidDomain(_a));
  }

protected:

  /// Bounding box of the root node.
  CICBBox     _bbox;
  /// Linear list of cache records.
  CRecordList _linList;
  /// Current value of the allowed cachng error.
  float       _a;
  /// Number of threads.
  int _numThreads;

  /// Octree statistics
  mutable struct {
    /// Number of successful queries (i.e. irradiance was interpolated). 
    counter_t numQueriesSuc;
    /// Number of unsuccessful queries (i.e. new irradiance value was computed).
    counter_t numQueriesFail;
    /// Number of weight calculations with zero response.
    counter_t numWeightZero;
    /// Number of weight calculations with nonzero response.
    counter_t numWeightNonzero;
    /// Number of times a record's radius was decreased (due to neighbor clamping).
    counter_t numDecreaseR;
    /// Number of times a record was moved in octree (due to radius shrinking).
    counter_t numMoveInOctree;
  } _stats;
 
#ifdef IC_PTHREADS
  /// @name Threading support attributes.
  //@{
  /// A R/W lock structure.
  mutable pthread_rwlock_t _rwlock;
  /// True if \ref _rwlock has been successfully initialized.
  bool    _rwlockok;
  //@}

  /// @name Threading support members.
  //@{
  /// Init the R/W lock.
  void _rwLockInit(int numthreads);
  /// Destroy the R/W lock.
  inline void _rwLockDestroy()  {if(_rwlockok)pthread_rwlock_destroy(&_rwlock);}
  /// Lock cache for writing.
  inline void _wrLock() const   {if(_rwlockok)pthread_rwlock_wrlock(&_rwlock);}
  /// Unlock cache after write lock.
  inline void _wrUnlock() const {if(_rwlockok)pthread_rwlock_unlock(&_rwlock);}
  /// Lock cache for reading.
  inline void _rdLock() const   {if(_rwlockok)pthread_rwlock_rdlock(&_rwlock);}
  /// Unlock cache after read lock.
  inline void _rdUnlock() const {if(_rwlockok)pthread_rwlock_unlock(&_rwlock);}
  //@}
#else
  inline void _rwLockInit(int numthreads) {}
  inline void _rwLockDestroy()   {}
  inline void _wrLock()  const   {}
  inline void _rdLock()  const   {}
  inline void _rdUnlock() const  {}
  inline void _wrUnlock() const  {}
#endif
};

/// List of irradiance cache records.
class CICRecord;
typedef CICTreeBase<CICRecord>::CRecordList CICRecordList;

#endif //  __RCOCTREE_H__
