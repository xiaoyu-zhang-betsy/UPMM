// ===================================================================
// $Id: icrecgeo.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// icrecord.h
//   Irradiance cache record definition
//   
// Initial coding by Jaroslav Krivanek (Nov 2007).

#ifndef __ICRECGEO_H__
#define __ICRECGEO_H__

#include "icconf.h"
#include "icvec3.h"

/// Geometry-related information of an irradiance cache record
/** No irradiance nor gradient is stored here. */
class CICRecordGeom
{
protected:

  /// Default constructor does nothing.
  CICRecordGeom()  {}

  /// Constructor of the cache entry.
  /**
    @param P (in) Record position.
    @param N (in) Surface normal at P.
    @param R (in) Record radius clamped betweeen _Rminus and _Rplus.
    @param unclampedR (in) Unclamped radius.
    @param Rminus (in) Radius clamping value at the record position (see Tabellion 2004).
    @param Rplus  (in) Radius clamping value at the record position (see Tabellion 2004).
  */
  CICRecordGeom(
    const CICVec3 &P,
    const CICVec3 &N,
    float R,
    float unclampedR,
    float Rminus,
    float Rplus):
    _P(P),
    _N(N),
    _sqrInvR(1.0f/(R*R)),
    _R(R),
    _unclampedR(unclampedR),
    _Rminus(Rminus),
    _Rplus(Rplus)
  { 
  }
   
 public:

   /// Set the (clamped) record radius.
   void SetR(const float R)           {_R=R; _sqrInvR=1.0f/(R*R); }
   /// Clamp the given value between @ref _Rminus and @ref _Rplus and set it to record radius.
   void SetRClamp(const float R)      {SetR(std::max<float>(std::min<float>(R,_Rplus),_Rminus));}
   /// Set the unclamped radius.
   void SetUnclampedR(const float uR) { _unclampedR=uR;}

   /// @name Data access
   //@{
   const CICVec3& GetP()           const { return _P; }
   const CICVec3& GetNormal()      const { return _N; }
   const CICVec3& GetN()           const { return _N; }
   float GetSqrInvR()              const { return _sqrInvR; }
   float GetR()                    const { return _R; }
   float GetUnclampedR()           const { return _unclampedR; }
   float GetRMinus()               const { return _Rminus; }
   float GetRPlus()                const { return _Rplus; }
   /// Return the actual valid domain radius. 
   /** Computed as a product of record's normalized radus R and the caching error a. */ 
   float GetValidDomain(const float a)  const { return _R*a; }
   //@}

   /// Compute weight of this record with respect to a given point.
   /**  
       @param a  (in) Allowed caching error. 
       @param a2 (in) Square root of the allowed caching error.
       @param w  (out)Computed weight value.
       @return
        - true if weight is non-zero and the value of 'w' is valid.
        - false if weight is zero and the value in 'w' is undefined.
     */
   inline bool ComputeWeight(
     const CICVec3  &P,
     const CICVec3  &N,
     const float    a,
     const float    a2,
     float          &w) const;

   /// Return the value of approx error 'a', that assures that 'this' record will
   /// certainly not be used at position 'point'.
   inline float FindJustExclusionA(
     const CICVec3       &point,
     const CICVec3       &normal) const;

   /// Is this behind r2 ?  Returns true=behind, false=not behind.
   inline bool Behind(const CICRecordGeom *r2,const float a) const;

 protected: // data
   /// Record position.
   CICVec3  _P;
   /// Surface normal at P.
   CICVec3  _N;
   /// 1/(R^2), where R is the harmonic mean distance.
   float    _sqrInvR;
   /// Radius clamped betweeen @ref _Rminus and @ref _Rplus.
   float    _R;
   /// Unclamped radius.
   /** Neighbor Clamping heuristic uses this value when record radius is decreased. */
   float    _unclampedR;
   /// Clamping values at the record position
   /** Neighbor Clamping heuristic uses this value when record radius is decreased. */
   float    _Rminus,_Rplus;
};


// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
inline float
CICRecordGeom::FindJustExclusionA(const CICVec3       &P,
                                  const CICVec3       &N) const
{
  float sqrDistance    =  SqrMagnitude(P-GetP());
  float e1             =  sqrDistance * GetSqrInvR();

  return  sqrtf(e1) - 1e-6f;
}


// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
inline bool
CICRecordGeom::Behind(const CICRecordGeom *r2,const float a) const
{
  CICVec3 diff = GetP() - r2->GetP();
  float sqrDistance = SqrMagnitude(diff);
  if(sqrDistance > IC_SMALL) {
    float di = DotProd(diff, (_N + r2->_N) );
    if (di*0.5 < -a*_Rminus-0.001)
    {return true;} // behind
  }

  return false; // not behind
}

// --------------------------------------------------------------------------
//  CICRecordGeom::ComputeWeight()
// --------------------------------------------------------------------------
inline bool
CICRecordGeom::ComputeWeight(const CICVec3 &P,
                             const CICVec3 &N,
                             const float    a,
                             const float    a2,
                             float          &weight) const
{
  CICVec3  diff = P - GetP();

  // -----------------------------
  //  reject based on distance ?
  // -----------------------------
  float sqrDistance  =  SqrMagnitude(diff);
  float epi2         =  sqrDistance * _sqrInvR;
  // float a2 = a*a;
  if(epi2 > a2) return false;

  // ------------------------------------------
  //  reject based on the normal divergence? 
  // ------------------------------------------
  // orientation error
  float dot = DotProd(N,GetN());
  if(dot<=IC_MIN_ALLOWED_DOT) return false;
  float eni2 = IC_SQR_ROT_MULT*(1.0f-dot);
  
  float e2 = epi2 + eni2;
  if(e2 > a2) return false;

  // -------------------------------------
  //  reject based on the 'behind' test?
  // -------------------------------------
  // Ward's test (from Radiance code)
  if(sqrDistance > IC_SMALL) {
    float di = DotProd(diff, (N + GetN()) );
    if (di*0.5 < -a*_Rminus-0.001)
    { return false; }
  }

  // -----------------------------
  //  compute weight
  // -----------------------------
#if 1
  // the simplest possible weight with no sqrt
  weight = 1.f - e2/a2;
#else
  float e = sqrtf(epi2);
  if(eni2 > 0) { 
    e += sqrtf(eni2);
    if (e > a) return false;
  }

  /// Tabellion weight (Tabellion and Lamorlette 2004)
  ///  - best results with least computation -
#if 0
  weight = 1.0f - e/a;
#endif

  /// Jarosz weight (Jarosz et al. 2008)
#if 0
  float d = 1.0f - e/a; 
  weight = d*(3*d - 2*d*d);
#endif

  /// Ward weight (Ward et al. 88)
#if 1
  if ( e <= IC_SMALL ) { weight = 1.0f / IC_SMALL; return true; }
  weight = 1.0f/e - 1.0f/a;
#endif

#endif

  return true;
}

#endif // __ICRECORD_H__
