// ===================================================================
// $Id: icmode.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// icmode.h
//      Caching mode for radiance and irradiance caching.
//
// Initial coding by Jaroslav Krivanek, November 2007.

#ifndef __ICMODE_H__
#define __ICMODE_H__

/// Caching behaviour for irradiance or radiance cache.
class CICMode {

public:

  enum EMode {

    /// Shall we look for samples in the cache?
		EE_LookIntoCache    = 1,
    /// Shall we insert samples into the cache?
    EE_InsertIntoCache  = 2,
    /// Shall we sample the hemisphere if nothing found in the cache? 
    EE_SampleHemisphere = 4,

    /// Normal caching behaviour. If something in the cache, return it. 
    /// Otherwise sample hemisphere and insert.
    EE_Normal       = EE_LookIntoCache|EE_InsertIntoCache|EE_SampleHemisphere,
    /// Do no use caching, always sample the hemisphere.
    EE_AlwaysSample = EE_SampleHemisphere,
    /// Always sample the hemisphere & insert the irradiance into the cache.
    EE_AlwaysInsert = EE_InsertIntoCache|EE_SampleHemisphere,
    /// Never sample the hemisphere. Read from cache. If nothing found, return 
    /// black.
    EE_AlwaysRead   = EE_LookIntoCache,
    /// Special value - use the same caching mode for higher order and 
    /// primary rays. Only applicable to higher order rays.
    EE_Same         = 10000,
    /// Unrecognized string value in SetFromString() method.
    EE_Error        = 50000
  };

  inline static int LookIntoCache(EMode m)   {return m & EE_LookIntoCache;}
  inline static int InsertIntoCache(EMode m) {return m & EE_InsertIntoCache;}
  inline static int SampleHemisphere(EMode m){return m & EE_SampleHemisphere;}
};

#endif //__ICMODE_H__
