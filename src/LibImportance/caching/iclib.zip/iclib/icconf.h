// ===================================================================
// $Id: icconf.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// icconf.h
//   Irradiance cache macros
//   
// Initial coding by Jaroslav Krivanek (Nov 2007).

#ifndef __ICCONF_H__
#define __ICCONF_H__

#ifndef _REENTRANT
#define _REENTRANT
#endif

// --------------------------------------------------------------------------
//  Static configuration parameters for irradiance caching.
//  You may want to play around with these defines, but you are not likely
//  to find better values than those specified here.
//  They were determined by some quite extensive testing.
// --------------------------------------------------------------------------

/// compile for the IC library for Arnold (using Arnold's messaging API)
// #define ARNOLD

/// synchronize with pthreads
// #define IC_PTHREADS

/// Save the results of the last cache query and reuse it in the same pixel.
/// Speeds up irradiance interpolation with high anti-aliasing.
#define IC_REUSE_LAST_RESULT 1

/// Use minimum of hit distances for the caching criterion (Tabellion & Lamorlette 2004) 
/// (as opposed to using the harmonic mean of hit distances (Ward et al. 88)
#define IC_USE_MIN_HIT_DIST 0

/// Ratio between the typical value of a for Ward's error metric and Tabellion's
/// error metric.
#define IC_A_RATIO  (0.25f/0.5f)

/// Multiplier for rotation's contribution to the weight function
/** 
   Ward uses 1. Since for Tabellion's error metric the typical value of a would be
   twice as big as for Ward, we use twice the multiplier for rotation.
 */
#if IC_USE_MIN_HIT_DIST==1
#define IC_ROT_MULT (1.0f/IC_A_RATIO)
#else
#define IC_ROT_MULT 1.0f
#endif

#define IC_SQR_ROT_MULT (IC_ROT_MULT*IC_ROT_MULT)

/// Maximum allowed dot product between the normal at a query point and
/// the accepted record's normal.
#define IC_MIN_ALLOWED_DOT 0.1f

/// A number considered "small" in caching geometric calculations
#define IC_SMALL 1e-3f

/// Maximum depth of the cache octree
#define IC_MAX_OCTREE_DEPTH  30
#define IC_OCTREE_STACK_SIZE (IC_MAX_OCTREE_DEPTH*8)

/// A very useful macro for debugging purposes.
#define IC_DEBUG       (std::cerr << "IC_DEBUG")
#define IC_PRINTVAR(a) std::cerr << #a"\t" << a << std::endl;

/// Math constants
#define IC_PI             (3.1415926535897931)   // pi double
#define IC_PIf            (3.1415926535897931f)  // pi float

/// set an array of 3 numbers to zero
template<class T> void setz3(T*v) { v[0]=v[1]=v[2]=0; }
/// copy an array of 3 numbers
template<class T> void mov3(T*dest, const T*src) { dest[0]=src[0];dest[1]=src[1];dest[2]=src[2];}

// ==========================================================

#ifdef _WIN32
#include <float.h>
#include <math.h>
#define isnan _isnan
#define isinf !_finite
#define ic_isnan(x)   (_isnan((x)))
#define ic_isinf(x)   (!_finite((x))) // exact opposite of isinf()
#else
#ifdef __cplusplus
using namespace std;          // for isnan(), isinf(),...
#endif
// standard C99 way
#include <math.h>
#define ic_isnan(x)            (isnan((x)))
#define ic_isinf(x)            (isinf((x)))
#endif
#define ic_isfinIte(x)         (!(ic_isnan((x)) || ic_isinf((x))))

// convenient macros to check for valid vectors and colors
#define ic_isfinite3(v)    (ic_isfinite((v)[0]) && ic_isfinite((v)[1]) && ic_isfinite((v)[2]))

#ifndef IC_NODE_NAME
#define IC_NODE_NAME "irrcache" 
#endif

// arnold-specific stuff
#ifdef ARNOLD

#include "ai_msg.h"

#define icMsgInfo     AiMsgInfo
#define icMsgDebug    AiMsgDebug
#define icMsgWarning  AiMsgWarning
#define icMsgError    AiMsgError
#define icMsgFatal    AiMsgFatal

#else

#define icMsgInfo     printf
#define icMsgDebug    printf
#define icMsgWarning  printf
#define icMsgError    printf
#define icMsgFatal    printf

#endif

#endif // __ICCONF_H__
