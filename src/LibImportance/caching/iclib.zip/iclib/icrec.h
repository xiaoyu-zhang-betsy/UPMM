// ===================================================================
// $Id: icrec.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// icrec.h
//   Irradiance cache record.
//   
// Initial coding by Jaroslav Krivanek (Nov 2007).

#ifndef __ICREC_H__
#define __ICREC_H__

#include "icconf.h"
#include "icvec3.h"
#include "icgrads.h"
#include "icrecgeo.h"

// --------------------------------------------------------------------------
//  class CICRecord 
// --------------------------------------------------------------------------

/// Complete irradiance cache record - geometry, irradiance & gradients.
class CICRecord : public CICRecordGeom /*, public CICRecordTransientInfo */ {

  friend class CICache;

  /// Default constructor (that does nothing) is only available to friends
  CICRecord() {}

public:

  /// Constructor of the cache record fills in all the entries.
   CICRecord(
     const CICVec3 &P,
     const CICVec3 &N,
     float R,
     float unclampedR,
     float Rminus,
     float Rplus,
     const CICVec3 &avgDirL,
     const CICVec3 &avgDirR,
     const CICVec3 &avgDirG,
     const CICVec3 &avgDirB,
     const float    E[],
     const CICVec3 *grads):
   CICRecordGeom(P,N,R,unclampedR,Rminus,Rplus),
     _avgDirL(avgDirL), _avgDirR(avgDirR), _avgDirG(avgDirG), _avgDirB(avgDirB)
   { 
     mov3(_E, E);
     if(grads) memcpy(&_grads[0], grads, 2*3*sizeof(CICVec3));
     else      memset(&_grads[0], 0,     2*3*sizeof(CICVec3));
	 data=0;
   }

   /// Set irradiance.
   void SetE(const float *newE) { for(int i=0; i<3; i++) _E[i]=newE[i]; }
   
   /// @name Data access
   //@{
   const float*   GetE()               const { return _E; }
   const CICVec3* GetRotGrad()         const { return _grads+0;   }
   const CICVec3* GetTransGrad()       const { return _grads+3; }
   const CICVec3& GetRotGrad(int i)    const { return _grads[i];   }
   const CICVec3& GetTransGrad(int i)  const { return _grads[i+3]; }
   void  GetAvgDirs(CICVec3& L,CICVec3& R,CICVec3& G,CICVec3& B) const
   { L=_avgDirL; R=_avgDirR; G=_avgDirG; B=_avgDirB; }
   const CICVec3& GetAvgDirL() const { return _avgDirL; }
   const CICVec3& GetAvgDirR() const { return _avgDirR; }
   const CICVec3& GetAvgDirG() const { return _avgDirG; }
   const CICVec3& GetAvgDirB() const { return _avgDirB; }
   //@}

   /// Get extrapolated irradiance at a given position (apply gradients to irradiance)
   void ExtrapolateIrradiance(
     const CICVec3& P,
     const CICVec3 &N,
     float *destE,
     int gradsUsed) const;

   /// pointer to additional data 
   void *data;
 protected: // data
   /// average direction of incoming light
   CICVec3  _avgDirL, _avgDirR, _avgDirG, _avgDirB;
   /// irradiance at P(N)
   float    _E[3];
   /// 3 rotation gradients followed by 3 translation gradients
   CICVec3  _grads[2*3];
};

// --------------------------------------------------------------------------
//  CICRecord::ExtrapolateIrradiance()
// --------------------------------------------------------------------------
inline void 
CICRecord::ExtrapolateIrradiance(const CICVec3 &P,
                                 const CICVec3 &N,
                                 float *destE,
                                 int gradsUsed) const
{
  const float *srcE = GetE();

  switch(gradsUsed)
  {
  case EE_NoGrads:
      mov3(destE,srcE);
      break;
  case EE_RotGrad:
    {
      // accumulate with rot/trans gradients
      CICVec3 nnorm = CrossProd(N, GetNormal());
      for(int i=0; i<3; i++)
        destE[i] = srcE[i] + DotProd(nnorm, GetRotGrad(i));
    }
    break;
  case EE_TransGrad:
    {
      // accumulate with rot/trans gradients
      CICVec3 diff  = P - GetP();
      for(int i=0; i<3; i++)
        destE[i] = srcE[i] + DotProd(diff,  GetTransGrad(i));
    }
    break;
  default:  
    {
      // accumulate with rot/trans gradients
      CICVec3 diff  = P - GetP();
      CICVec3 nnorm = CrossProd(N, GetNormal());
      for(int i=0; i<3; i++)
        destE[i] = srcE[i] + DotProd(diff,  GetTransGrad(i)) + DotProd(nnorm, GetRotGrad(i));
    }
    break;
  }
}

#endif // __ICREC_H__
