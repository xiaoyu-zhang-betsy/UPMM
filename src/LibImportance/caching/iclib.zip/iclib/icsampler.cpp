// ==================================================================
// $Id: icsampler.cpp,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// icsampler.cpp
//    Support routines for sampling diffuse hemisphere.
//    Used for irradiance caching.
//
// Initial coding by Jaroslav Krivanek, Nov 2007

// ic-lib headers
#include "icsampler.h"

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
inline int 
CICSamplerStratified::_findValidFwd(const CHemiSample *hs, int M, int begin, int end)
{
  for(int i=begin; i<end; i++)
    if(hs[idx(0,i, M)].ir>0) return i;
  return -1;
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
inline int 
CICSamplerStratified::_findValidBwd(const CHemiSample *hs, int M, int begin, int end)
{
  for(int i=end-1; i>=begin; i--)
    if(hs[idx(0,i, M)].ir>0) return i;
  return -1;
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
inline int 
CICSamplerStratified::_findInvalidFwd(const CHemiSample *hs, int M, int begin, int end)
{
  for(int i=begin; i<end; i++)
    if(hs[idx(0,i, M)].ir<=0) return i;
  return -1;
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
inline void 
CICSamplerStratified::_lintp(CHemiSample *hs, int M, int N, int first, int last)
{
  int len = last - first;
  CTriCol L = hs[idx(0,first%N, M)].Li;
  float   r = hs[idx(0,first%N, M)].ir;
  CTriCol Ldiff = (hs[idx(0,last%N, M)].Li-L)/(float)len;
  float   rdiff = (hs[idx(0,last%N, M)].ir-r)/(float)len;
  for(int i=first+1; i<last; i++) {
    L += Ldiff; r += rdiff;
    hs[idx(0,i%N, M)].Li = L;
    hs[idx(0,i%N, M)].ir = r;
  }
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
void 
CICSamplerStratified::_fillGaps(CHemiSample *hs, int M, int N)
{
  // ----------------------------------------
  // first row first - linear interpolation
  // ----------------------------------------
  int first = _findValidFwd(hs,M, 0,N);
  if(first==-1) {
    icMsgDebug("[%s]  CICSamplerStratified::_fillGaps(): No valid ray in hemisphere sampling.", IC_NODE_NAME);
    for(int i=0; i<N*M; i++) { hs[i].Li.setz(); hs[i].ir = 100; } // let it be seen in the image
  }

  int last = _findValidBwd(hs,M, 0,N);

  // special handling of missing items at the beginning and/or at the end of the row
  if(first == last) {
    // fill the whole array with the signle valid value
    CTriCol L = hs[idx(0,first, M)].Li;
    float   r = hs[idx(0,first, M)].ir;
    for(int i=0; i<N; i++) {
      hs[idx(0,i, M)].Li = L;
      hs[idx(0,i, M)].ir = r;
    }
  }
  else {
    if (first!=0 || last!=N-1) {
      // interpolate from last to first (around the end)  [XXXXXfirst        lastXXXX]
      _lintp(hs,M,N, last,first+N);
    }
    // at this point, the very first and very last items are certainly valid - fill the rest
    int next = first;
    while(1) {
      if( (first=_findInvalidFwd(hs,M, next,N)) == -1 )
        break; // no gaps to fill
      next = _findValidFwd(hs,M, first,N); // we made sure this will succeed
      if(first+1==next) {
        // single missing item in the gap
        hs[idx(0,first, M)].Li = 0.5f*( hs[idx(0,first-1, M)].Li + hs[idx(0,first+1, M)].Li );
        hs[idx(0,first, M)].ir = 0.5f*( hs[idx(0,first-1, M)].ir + hs[idx(0,first+1, M)].ir );
      }
      else {
        // more missing items in the gap
        _lintp(hs,M,N, first-1,next);
      }
    }
 }
  // the first row is filled now

  // --------------------------------------------
  //  subsequent rows - copy from previous rows
  // --------------------------------------------
  for(int j=1; j<M; j++) {
    for (int k=0; k<N; k++) {
      int i = idx(j,k, M);
      if(hs[i].ir <= 0) {
        int i1 = idx(j-1,k, M);
        hs[i].Li = hs[i1].Li;
        hs[i].ir = hs[i1].ir;

        if(hs[i1].ir<=0) {
          icMsgDebug("[%s]  Consistency: extrapolated hemi cell is invalid", IC_NODE_NAME);
        }
      }
    }
  }
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
void
CICSamplerWard::_transGradient(CICVec3 *transGrad,
                               const CHemiSample *hemiSamples, int M, int N,
                               const CICVec3& X, const CICVec3& Y)
{
	CTriCol xd(0.f), yd(0.f);

	for (int k = 0; k < N; k++) 
  {
    CTriCol magu(0.f), magv(0.f);
		float lastsine = 0;

		for (int j = 0; j < M; j++) 
    {
      const CHemiSample &hsjk = hemiSamples[idx(j,k, M)];
      if (j > 0) 
      {
        const CHemiSample &hsj1k = hemiSamples[idx(j-1,k, M)];
        float invr = std::max( hsjk.ir, hsj1k.ir );
				float sin_mul_cos2_j = lastsine * (1.0f - (float)j/M);
        magu += (hsjk.Li - hsj1k.Li) * ( sin_mul_cos2_j * invr );
			}

			float nextsine = sqrt((float)(j+1)/M);

      // v - translational gradient
      const CHemiSample &hsjk1 = hemiSamples[(k==0) ? idx(j,N-1, M) : idx(j,k-1, M)];
      float invr = std::max(hsjk.ir, hsjk1.ir);
      float sin_diff_j = nextsine - lastsine;
      magv += (hsjk.Li - hsjk1.Li) * (sin_diff_j * invr);

			lastsine = nextsine;
		}

		magu *= 2.f*IC_PIf/N;
		float phi  = 2.f*IC_PIf * (float)k/N;
		float cosp = cos(phi), sinp = sin(phi);
		xd += magu*cosp - magv*sinp;
		yd += magu*sinp + magv*cosp;
	}

  for(int c=0; c<3; c++)
    transGrad[c] =  X * xd[c] + Y * yd[c];

}


// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
void
CICSamplerWard::_rotGradient(CICVec3 *rotGrad,
                             const CHemiSample *hemiSamples, int M, int N,
                             const CICVec3& X, const CICVec3& Y)
{
  CTriCol  xd(0.f), yd(0.f);

  for (int k=0; k<N; k++) 
  {
    CTriCol mag(0.f);

    for (int j=0; j<M; j++) 
    {
      const float cotan_theta = 1 / sqrt(M/(j+.5f) - 1.0f);
      mag -= hemiSamples[idx(j,k, M)].Li * cotan_theta;
    }

    float phi = 2*IC_PIf*(k+.5f)/N + IC_PIf/2;
    xd += mag * cos(phi);
    yd += mag * sin(phi);
  }

  for(int c=0; c<3; c++)
    rotGrad[c] =  IC_PIf/(M*N) * ( X * xd[c] + Y * yd[c] );
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
void
CICSamplerWard::_computeIrradiance(float outE[3], const CHemiSample *hemiSamples, int M, int N)
{
  CTriCol E(0.0);
  for(int i=0; i<M*N; i++)
    E += hemiSamples[i].Li;
  E *= (IC_PIf/(M*N));
  E.CopyData(outE);
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
void
CICSamplerWard::_computeAggregates(CICVec3       &outAvgDirL,
                                   CICVec3       &outAvgDirR,
                                   CICVec3       &outAvgDirG,
                                   CICVec3       &outAvgDirB,                                  
                                   float          outE[3], 
                                   const CHemiSample *hemiSamples, int M, int N)
{
  CTriCol E(0.0);
  CICVec3 avgDirL(0.0), avgDirR(0.0), avgDirG(0.0), avgDirB(0.0);

  for(int i=0; i<M*N; i++) 
  {
    const CHemiSample &hs = hemiSamples[i];
    E += hs.Li;
    avgDirL += hs.dir * hs.Li.Luminance();
    avgDirR += hs.dir * hs.Li.r;
    avgDirG += hs.dir * hs.Li.g;
    avgDirB += hs.dir * hs.Li.b;
  }
  E *= (IC_PIf/(M*N));
  E.CopyData(outE);

  outAvgDirL = SafeNormalize(avgDirL);
  outAvgDirR = SafeNormalize(avgDirR);
  outAvgDirG = SafeNormalize(avgDirG);
  outAvgDirB = SafeNormalize(avgDirB);
}


// --------------------------------------------------------------------------
//  CICSamplerWard::_medianFilter3x3()
// --------------------------------------------------------------------------
/*
#include <vector>
#include <algorithm>

void
CICSamplerWard::_medianFilter(CTriCol *Li) const
{
  // This is a very unoptimized version only for testing purposes.
  // Since median filtering on the hemisphere turned out not to be 
  // a very good idea, this is actually not used.
  static const int r = 1;
  static const int area = (2*r+1)*(2*r+1);
  std::vector<float> R(area), G(area), B(area);

  // phi intervals
  for (int k=0; k<N; k++) {
    // theta intervals
    for(int j=0; j<M; j++) {
      // filter extent
      for(int y=k-r, i=0; y<=k+r; y++) {
        for(int x=j-r; x<=j+r; x++, i++) {
          int iii = idxo(x,y);
          R[i] = Li[iii].r;
          G[i] = Li[iii].g;
          B[i] = Li[iii].b;
        }
      }
      // sort arrays
      std::sort(R.begin(),R.end()); 
      std::sort(G.begin(),G.end()); 
      std::sort(B.begin(),B.end());

      Li[idx(j,k)].Set(R[area/2], G[area/2], B[area/2]);
    }
  }
}
*/
