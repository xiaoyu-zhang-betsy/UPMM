// ===================================================================
// $Id: icbase.h,v 1.2 2010/02/25 17:51:02 jaroslav Exp $
//
// icbase.h
//     Common functionality for radiance and irradiance caching.
//
// Class: CCachingBase
//
// Initial coding by Jaroslav Krivanek, Nov 2007.

#ifndef __ICBASE_H__
#define __ICBASE_H__

// ic-lib headers
#include "icconf.h"
#include "icmode.h"
#include "icgrads.h"

// The following code chooses one of the tree implementations.

#include "ictree01.h"
// #include "ictree02.h"
// #include "ictree03.h"

//#define BASETREE CICOctree01
//#define BASETREE CICOctree02
//#define BASETREE CICBVH03

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
/// Common functionality for radiance and irradiance caching.
template<class TRecord>
class CCachingBase : public CICOctree01<TRecord>
{
public: // data types

  /// Class that implements a data structure used to index cache records.
  typedef CICOctree01<TRecord> TTree;

  /// Class holding constructor parameters for the CCachingBase class.
  class CConstructParams : public TTree::CConstructParams {
  public:
    /// empty default constructor
    CConstructParams() {}
  };

  /// Return value of the cache query methods.
  enum EQueryResult {
    /// Cache query failed.
    EE_Failed = 0,
    /// Cache query succeeded. Interpolation used.
    EE_Interpolated,
    /// Cache query succeeded. New record added.
    EE_NewRecord
  };

public: // methods

  /// Construct the octree and set parameters that determine caching behavior.
  CCachingBase(const CConstructParams &p) :
    TTree(p)
  {
    // default values
    _minDist = 1.5f;
    _maxDist = 20.0f;
    _gradsUsed = EE_RotGrad | EE_TransGrad;
    _clampInScreenSpace = true;
    _clampRadiusByGradients = true;
    _clampByNeighbors = true;
    _clampNeighbors = true;
    // no record visualization by default
    _visualizeNewRecPos = false;
    _visualizeRecPos    = false;
    _visualRecSize      = 0.5;
    _visualRecColor.Set(10);
    _visualNewRecColor.Set(10);
    // set the caching mode to the usual lazy evaluation
    SetCachingMode(CICMode::EE_Normal);
  }

  /// Set the caching mode.
  inline void SetCachingMode(CICMode::EMode m);
  
  /// Return the caching mode.
  CICMode::EMode GetCachingMode(void) const { return _cachingMode; }

  /// Set parameters for record visualization.
  /** 
     @param s (in) spot size
     @param c (in) spot color
   */
  inline void SetRecPosVisualParams(float s,const CTriCol& c)
  { _visualRecSize = s; _visualRecColor = c; }
  /// Turn record visualization on / off.
  inline void VisualizeRecPos(bool v) { _visualizeRecPos=v; }

  /// Set color for visualization of newly added records.
  /** @param c (in) pixel color */
  inline void SetNewRecPosVisualParams(const CTriCol& c)
  { _visualNewRecColor = c; }
  /// Turn on / off visualization of new records.
  inline void VisualizeNewRecPos(bool v) { _visualizeNewRecPos=v; }

  void SetMinMaxSpacing(float mi, float ma) { _minDist=max(0.001f,mi); _maxDist=max(_minDist,ma); }
  void UseGradients(bool b) { if(b) _gradsUsed|=EE_AllGrads;  else _gradsUsed &= ~EE_AllGrads;  }
  void UseRotGrad(bool b)   { if(b) _gradsUsed|=EE_RotGrad;   else _gradsUsed &= ~EE_RotGrad;   }
  void UseTransGrad(bool b) { if(b) _gradsUsed|=EE_TransGrad; else _gradsUsed &= ~EE_TransGrad; }
  int  RotGradUsed()   { return _gradsUsed & EE_RotGrad; }
  int  TransGradUsed() { return _gradsUsed & EE_TransGrad; }
  void ClampInScreenSpace(bool b)        { _clampInScreenSpace = b; }
  void ClampRadiusByGradients(bool b)    { _clampRadiusByGradients = b; }
  void ClampByNeighbors(bool b)          { _clampByNeighbors = b; }
  void ClampNeighbors(bool b)            { _clampNeighbors = b; }
  bool isRecVisualizetionOn() const      { return _visualizeNewRecPos || _visualizeRecPos; }

  /// Helper function to clamp a given value beetween the givem minumum and maximum.
  static inline float Clamp(float val, float low, float high) 
  {
    if (val < low) return low;
    else if (val > high) return high;
    else return val;
  }

protected: /// methods

  /// Return the color based on the proximity of cache records.
  float _visualizeNearestRecords(
    const CICVec3  &P,
    const CICVec3  &N,
    const float size) const;

  /// Returns the visualization intensity given the normalized distance.
  static inline float _visualizationProfile(float sqrNormDist);

  /** @brief Return either the first or the second parameter, depending on the 
       value of @ref IC_USE_MIN_HIT_DIST. */
  inline float _chooseR(const float minHitDist,const float harmMeanDist) const;

  /// Transform Rmin and Rmax to object space.
  inline void _setRminusRplus(
    float &Rminus,
    float &Rplus,
    const float pixelSize) const;

  /// Return true if r1 is behind r2 or r2 behind r1 (behind test from Radiance code).
  bool _mutuallyBehind(const TRecord* r1, const TRecord* r2);

  /// Helper function for AddIrradiance() - implements the neighbor clamping heuristic.
  void _neighborClamping(TRecord* newrec, int recursionDepth=0);

protected:
  /// Bitmask indicating gradients used for interpolation (none and/or translation and/or rotation)
  int _gradsUsed;
  /// Minimum allowed spacing of records.
  float _minDist;
  /// Maximum allowed spacing of records.
  float _maxDist;
  /** @brief Clamp the harmonic mean distance of a new record by minDist/maxDist 
      in screen space (as opposed to object space). */
  bool  _clampInScreenSpace;
  /// Clamp the radius of a record by the translational gradient.
  /** The idea comes from Greg Ward and Radiance code. */
  bool  _clampRadiusByGradients;
  /// Clamp radius of the new record based on neighbors' radii (= first half of neighbor clamping).
  bool  _clampByNeighbors;
  /// Clamp radius of neighbors based on the new record's radius  (= second half of neighbor clamping).
  bool  _clampNeighbors;

  /// Caching mode. Determines the caching behavior.
  CICMode::EMode _cachingMode;

  /// Visualize position of newly added records.
  bool   _visualizeNewRecPos;
  /// Visualize positions of all records. 
  bool   _visualizeRecPos;
  /// Size of the visualized record position in pixels.
  float  _visualRecSize;
  /// Color used to visualize record positions.
  CTriCol _visualRecColor;
  /// Color used to visualize positions of newly added records.
  CTriCol _visualNewRecColor;
};

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
inline void 
CCachingBase<TRecord>::SetCachingMode(CICMode::EMode m)
{
  assert(m!=CICMode::EE_Same);
  assert(m!=CICMode::EE_Error);
	_cachingMode = m;
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
inline float 
CCachingBase<TRecord>::_chooseR(const float minHitDist,const float harmMeanDist) const
{
  if(IC_USE_MIN_HIT_DIST) {
    // Use minimum hit distance for R. 
    return minHitDist;
  }
  else {
    // Use harmonic mean distance for R.
    return harmMeanDist;
  }
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
inline void 
CCachingBase<TRecord>::_setRminusRplus(float &Rminus,
                                       float &Rplus,
                                       const float pixelSize) const
{
  if(_clampInScreenSpace) {
    // Clamp in screen space.
    Rminus = _minDist * pixelSize/TTree::_a;
    Rplus  = _maxDist * pixelSize/TTree::_a;
  }
  else {
    // Clamp in object space
    Rminus = _minDist/TTree::_a;
    Rplus  = _maxDist/TTree::_a;
  }
}

#endif // __ICBASE_H__
