// ===================================================================
// $Id: ictree01.cpp,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// Initial coding by Jaroslav Krivanek (nov 2007).

#include "iccontrib.h"
#include "icrec.h"
#include "ictree01.h"

// #include <algorithm>

#define IC_OCTREE01_SCALE 3.0f

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
CICOctree01<TRecord>::CNode::~CNode()
{
  // delete children
  for(int i=0; i<8; i++)
    delete children[i];
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
CICOctree01<TRecord>::CICOctree01 (const typename CICOctree01<TRecord>::CConstructParams& p)
: CICTreeBase<TRecord>(p)
{
  _setupRoot(p.bbox);
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
void 
CICOctree01<TRecord>::_setupRoot(const CICBBox& bbox)
{
  // use a cubic box, slightly bigger than the scene
  CICVec3 boxCenter = bbox.Center();
  float halfSideLen = 0.55f * bbox.Diagonal().MaxComponent();

  this->_bbox.pMin = boxCenter-CICVec3(halfSideLen);
  this->_bbox.pMax = boxCenter+CICVec3(halfSideLen);

  this->_root = new CNode(boxCenter,halfSideLen);
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
CICOctree01<TRecord>::~CICOctree01 ()
{
  this->_wrLock();

  // delete octree nodes recursively
  delete this->_root;

  // delete (ir)radiance records
  for(typename CRecordList::const_iterator it=this->_linList.begin(); it!=this->_linList.end(); ++it)
    delete *it;

  this->_wrUnlock();

  this->_rwLockDestroy();
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
void CICOctree01<TRecord>::Clear ()
{
  this->_wrLock();

  // delete octree nodes recursively
  delete this->_root;

  // delete (ir)radiance records
  for(typename CRecordList::const_iterator it=this->_linList.begin(); it!=this->_linList.end(); ++it)
    delete *it;
  _linList.clear();

  // create new root node with the current bounding box
  this->_root = new CNode(_bbox.Center(), 0.5f*_bbox.Diagonal().MaxComponent());

  this->_wrUnlock();
}



// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
bool
CICOctree01<TRecord>::HasContribution(const CICVec3  &P,
									  const CICVec3  &N) const
{
  this->_rdLock();

  const float a2 = this->_a * this->_a;

  const CNode *node = this->_root;

  while(node) {

    // run throug the list of the current node
    CRecordContrib<TRecord> item;
    const CRecordList &nodeList = node->recList;
    typename CRecordList::const_iterator iter = nodeList.begin();
    for ( ; iter != nodeList.end(); iter++) {
      item.rec = *iter;
      if( item.rec->ComputeWeight(P,N,this->_a,a2,item.w) ) {
        this->_stats.numWeightNonzero++;
        this->_stats.numQueriesSuc ++;
        this->_rdUnlock();
        return true; // interpolation possible
      }
      else {
        this->_stats.numWeightZero++;
      }
    }

    // Determine which octree child node _p_ is inside
    const CICVec3 &pMid = node->boxCenter;

    int childIdx = 
      (P.x > pMid.x ? 4 : 0) +
      (P.y > pMid.y ? 2 : 0) + 
      (P.z > pMid.z ? 1 : 0);

    node = node->children[childIdx];
  }

  // end of tree traversal
  this->_stats.numQueriesFail ++;
  this->_rdUnlock();
  return false;
}


// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
bool
CICOctree01<TRecord>::GetContributions(const CICVec3  &P,
                                       const CICVec3  &N,
                                       const int       tid,
                                       CRecordContribArray<TRecord> &carray) const
{
  this->_rdLock();

  const float a2 = this->_a*this->_a;

  size_t itemsBefore = carray.size();

  const CNode *node = this->_root;

  while(node) {

    // run throug the list of the current node
    CRecordContrib<TRecord> item;
    const CRecordList &nodeList = node->recList;

    typename CRecordList::const_iterator iter = nodeList.begin();
    for ( ; iter != nodeList.end(); ++iter) {
      item.rec = *iter;
      if( item.rec->ComputeWeight(P,N,this->_a,a2,item.w) ) {
        this->_stats.numWeightNonzero++;
        carray.push_back(item);
      }
      else {
        this->_stats.numWeightZero++;
      }
    }

    // Determine which octree child node _p_ is inside
    const CICVec3 &pMid = node->boxCenter;

    int childIdx = 
      (P.x > pMid.x ? 4 : 0) +
      (P.y > pMid.y ? 2 : 0) + 
      (P.z > pMid.z ? 1 : 0);

    node = node->children[childIdx];
  }

  // end of tree traversal

#if 0
  //searchFailed = false;
  //////////////////////////////////////////
  // validate octree results by using the linear list
  {
    CRecordContribArray<TRecord> lincarray;
    lincarray.clear();

    CRecordContrib<TRecord> item;
    CRecordList::const_iterator iter=_linList.begin();
    for ( ; iter != _linList.end(); ++iter) {
      item.rec = *iter;
      if( item.rec->ComputeWeight(P,N,_a,a2,item.w) )
        lincarray.push_back(item);
    }

    if(lincarray.size()!=carray.size()) {
      //searchFailed = true;

      IC_DEBUG << "======= Octree failed!!! ===========" << std::endl;
      IC_PRINTVAR(lincarray.size());
      IC_PRINTVAR(carray.size());
      IC_PRINTVAR(P);
      //IC_PRINTVAR(_boxMin);
      //IC_PRINTVAR(_boxMax);

      unsigned c,l;
      for(c=0; c<carray.size(); c++) {
        for(l=0; l<lincarray.size(); l++)
          if(lincarray[l].rec == carray[c].rec)
            break;
        if(l==lincarray.size()) {
          IC_DEBUG << "record " << carray[c].rec->GetP() << "not found in linarray" << std::endl;
        }
      }

    }
    else {
      // sorting predicate - sort by record pointer
      class CRecSortPredicate { 
      public:
        bool operator()(const CRecordContrib<TRecord>& a,const CRecordContrib<TRecord>& b)
        {return a.rec<b.rec;}
      };
      std::sort(lincarray.begin(),lincarray.end(),CRecSortPredicate());
      std::sort(carray.begin(),carray.end(),CRecSortPredicate());

      for(unsigned i=0; i<carray.size(); i++) {
        if(lincarray[i].rec != carray[i].rec) {
          IC_DEBUG << "======= Octree failed (different records)!!! =======" << std::endl;
          IC_PRINTVAR(lincarray.size());
          IC_PRINTVAR(carray.size());
          //searchFailed = true;
        }
      }
    }

  }
  //////////////////////////////////////////
#endif

  this->_rdUnlock();

  if(carray.size()>itemsBefore) {
    this->_stats.numQueriesSuc ++;
    return true;
  }
  else {
    this->_stats.numQueriesFail ++;
    return false;
  }
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
bool
CICOctree01<TRecord>::_enlargeBBox(TRecord *rec)
{
  CICBBox recBox = GetRecBBox(rec);
  if(this->GetNumRecords()==0 && !this->_bbox.Contains(recBox)) 
  {
    // handle the first record separately
    float boxSideLen2 = 1.05f * rec->GetValidDomain(this->_a);
    const CICVec3 P = rec->GetP();

    this->_bbox.pMin = P - CICVec3(boxSideLen2);
    this->_bbox.pMax = P + CICVec3(boxSideLen2);

    this->_root->boxCenter   = P;
    this->_root->halfSideLen = boxSideLen2;
  }
  else
  {
    bool enlarged = false;

    // std::cerr << "recBox: " << recBox.pMin << recBox.pMax << std::endl;

    while( !this->_bbox.Contains(recBox) )
    {
      // enlarge the bounding box (first from the side, where the overlap is lower, but nonzero)
      float childSideLen = this->_bbox.pMax[0] - this->_bbox.pMin[0];
      int   childIdx = 0;

      // std::cerr << "bbox: " << _bbox.pMin << _bbox.pMax << std::endl;

      CICVec3 l_overlap = this->_bbox.pMin - recBox.pMin;
      CICVec3 r_overlap = recBox.pMax - this->_bbox.pMax;

      for(int i=0; i<3; i++)
      {
        // if( l_overlap[i] > r_overlap[i] && l_overlap[i] > 0 )
        if( fabsf(l_overlap[i]) < fabsf(r_overlap[i]) )
        {
          this->_bbox.pMin[i] -= childSideLen;
          childIdx |= ( 1<<(2-i) );
        }
      }
      this->_bbox.pMax = this->_bbox.pMin + CICVec3(2*childSideLen);

      // replace the root
      CNode *newRoot = new CNode( this->_bbox.Center(), childSideLen);
      
      newRoot->children[childIdx] = this->_root;
      this->_root = newRoot;
      enlarged = true;
    };

    // if(enlarged) std::cerr << "BBox enlarged to: " << _bbox.pMin << _bbox.pMax << std::endl;
  }

  return false; // ok
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
bool
CICOctree01<TRecord>::InsertRecord(TRecord *rec)
{
  assert(rec);

  this->_wrLock();

  // if(! _bbox.Contains(rec->GetP()) ) { _enlargeBBox(rec); }
  this->_enlargeBBox(rec);

  const CICVec3 &p = rec->GetP(); 
  float r = rec->GetValidDomain(this->_a);
  CICBBox dataBound(p-CICVec3(r),p+CICVec3(r));
  float diag2 = SqrDistance(dataBound.pMin, dataBound.pMax);

  this->_insertRecursive(this->_root, this->_bbox, rec, dataBound, diag2, 0);
  this->_linList.push_back(rec);

  this->_wrUnlock();

  return false; // ok
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template <class TRecord>
void 
CICOctree01<TRecord>::_insertRecursive(
		CNode *node, 
    const CICBBox &nodeBound,
		TRecord *rec,
    const CICBBox &dataBound,
		float diag2,
    int depth)
{
	// Possibly add data item to current octree node
  if (depth >= IC_MAX_OCTREE_DEPTH ||  SqrDistance(nodeBound.pMin,nodeBound.pMax)*IC_OCTREE01_SCALE   < diag2) {
    _storeInNode(node,rec);
    return;
  }

	// Otherwise add data item to octree children
	const CICVec3 pMid = nodeBound.Center();
	// Determine which children the item overlaps
	bool over[8];
	over[0] = over[1] = over[2] = over[3] = (dataBound.pMin.x <= pMid.x);
	over[4] = over[5] = over[6] = over[7] = (dataBound.pMax.x  > pMid.x);
	over[0] &= (dataBound.pMin.y <= pMid.y);
	over[1] &= (dataBound.pMin.y <= pMid.y);
	over[4] &= (dataBound.pMin.y <= pMid.y);
	over[5] &= (dataBound.pMin.y <= pMid.y);
	over[2] &= (dataBound.pMax.y  > pMid.y);
	over[3] &= (dataBound.pMax.y  > pMid.y);
	over[6] &= (dataBound.pMax.y  > pMid.y);
	over[7] &= (dataBound.pMax.y  > pMid.y);
	over[0] &= (dataBound.pMin.z <= pMid.z);
	over[2] &= (dataBound.pMin.z <= pMid.z);
	over[4] &= (dataBound.pMin.z <= pMid.z);
	over[6] &= (dataBound.pMin.z <= pMid.z);
	over[1] &= (dataBound.pMax.z  > pMid.z);
	over[3] &= (dataBound.pMax.z  > pMid.z);
	over[5] &= (dataBound.pMax.z  > pMid.z);
	over[7] &= (dataBound.pMax.z  > pMid.z);
	for (int child = 0; child < 8; ++child) {
		if (!over[child]) continue;

		// Compute _childBound_ for octree child _child_
		CICBBox childBound;
		childBound.pMin.x = (child & 4) ? pMid.x : nodeBound.pMin.x;
		childBound.pMax.x = (child & 4) ? nodeBound.pMax.x : pMid.x;
		childBound.pMin.y = (child & 2) ? pMid.y : nodeBound.pMin.y;
		childBound.pMax.y = (child & 2) ? nodeBound.pMax.y : pMid.y;
		childBound.pMin.z = (child & 1) ? pMid.z : nodeBound.pMin.z;
		childBound.pMax.z = (child & 1) ? nodeBound.pMax.z : pMid.z;

    if(childBound.OverlapsSphere(rec->GetP(),rec->GetValidDomain(this->_a))) 
    {
      CNode *son = 
        node->GetSonAlloc(child,childBound.Center(),(childBound.pMax.x-childBound.pMin.x)*0.5f);
      _insertRecursive(son, childBound, rec, dataBound, diag2, depth+1);
    }
	}
}


// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
int
CICOctree01<TRecord>::FindInInfluenceArea(const CICVec3  &P,
                                          const CICVec3  &N,
                                          const float     Radd,
                                          typename CICOctree01<TRecord>::CTreeLocArray &larray) const
{
  this->_rdLock();

  CTraversalStackEntry stack[IC_OCTREE_STACK_SIZE];
  stack[0].Set(_root);
  int stackEnd=1, nFound=0;
  CTreeLoc item;
    
  while(stackEnd>0) {
    // pop from the stack
    const CNode* node = stack[--stackEnd].node;

    // iterate over this node's records
    const CRecordList &recList = node->recList;
    typename CRecordList::const_iterator iter = recList.begin();
    for (  ; iter != recList.end(); iter++) {
      item.rec = *iter;
      if( DotProd(N,item.rec->GetNormal()) < IC_MIN_ALLOWED_DOT ) continue;
      float maxDist = item.rec->GetValidDomain(this->_a) + Radd;
      if( SqrDistance(P,item.rec->GetP()) < sqr(maxDist) ) {
        // store the contribution
        larray.push_back(item);
        nFound++;
      }     
    } // for

    // traverse children
    const CNode *son;
    for (int i=0; i<8; i++)
      if ( (son=node->children[i]) )  {
        if(son->GetBBox().OverlapsSphere(P,Radd))
          stack[stackEnd++].Set(son);    
      }
  }

  /*
  // validation with linear search
  CRecordTreeLocArray<TRecord> larray2;

  // use linear list
  const CRecordList &recList = GetRecordList();
  CRecordList::const_iterator iter = recList.begin();
  for (  ; iter != recList.end(); iter++) {
    item.rec = *iter;
    if( DotProd(N,item.rec->GetNormal()) < IC_MIN_ALLOWED_DOT ) continue;
    float maxDist = item.rec->GetValidDomain(_a) + Radd;
    if( SqrDistance(P,item.rec->GetP()) < sqr(maxDist) ) {
      // store the contribution
      larray2.push_back(item);
      // nFound++;
    }     
  } // for

  for(size_t j,i=0; i<larray2.size(); i++) {
    const TRecord *rec = larray2[i].rec;
    for(j=0; j<larray.size(); j++) {
      if(larray[j].rec == rec) break;
    }
    if(j==larray.size()) { 
      IC_DEBUG << "FindInInfluenceArea failed" << std::endl; 
    }
  }
  */

  this->_rdUnlock();

  // end of tree traversal
  return nFound;
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
int
CICOctree01<TRecord>::FindInRange(const CICVec3& P, 
                                const CICVec3& N,
                                float R,
                                typename CICOctree01<TRecord>::CTreeLocArray &larray) const
{
  this->_rdLock();

  CTraversalStackEntry stack[IC_OCTREE_STACK_SIZE];
  stack[0].Set(_root);
  int stackEnd=1, nfound=0;
  float R2 = R*R;
  CTreeLoc loc;

  while(stackEnd>0) {
    // pop from the stack
    const CNode *node = stack[--stackEnd].node;

    // reject if no possible candidates
    const CICBBox  &nodebox  = node->GetBBox();
    if (P.x < nodebox.pMin.x - R ) continue;
    if (P.y < nodebox.pMin.y - R ) continue;
    if (P.z < nodebox.pMin.z - R ) continue;
    if (P.x > nodebox.pMax.x + R ) continue;
    if (P.y > nodebox.pMax.y + R ) continue;
    if (P.z > nodebox.pMax.z + R ) continue;

    // run through the list of the current node
    const CRecordList &nodeList = node->recList;
    typename CRecordList::const_iterator it;
    for(it=nodeList.begin(); it!=nodeList.end(); ++it) {
      loc.rec = *it;
      // only accept record whose center is inside the octree node
      if( !nodebox.Contains(loc.rec->GetP()) ) continue;
      // accept only records facing in a similar direction
      if( DotProd(N, loc.rec->GetNormal()) <= IC_MIN_ALLOWED_DOT ) continue;
      // distance test
      if(SqrMagnitude(P - loc.rec->GetP()) < R2) {
        larray.push_back(loc);
        nfound++;
      }
    }

    // for all descendants
    for (int i = 0; i < 8; i++)
      if ( node->children[i] )
        stack[stackEnd++].Set(node->children[i]);

  }

  this->_rdUnlock();

  return nfound;
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
// explicit instantiation of CICOctree01 for TRecord=CICRecord
template class CICOctree01<CICRecord>;
