// ===================================================================
// $Id: aabb_tmpl.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// aabb_templ.h
//    Axis alligned bounding box template.
//
// Class: fixvector
//
// Initial coding by Jaroslav Krivanek, March 2008.

#ifndef __AABB_TMPL_H__
#define __AABB_TMPL_H__

#include <ostream>
using namespace std;

/// Axis aligned bounding box
template<class TVector3>
class CAABBTmpl 
{

public: // CAABBTmpl Public Methods

  CAABBTmpl() {}

  CAABBTmpl(const TVector3 &p) : pMin(p), pMax(p) { }

  CAABBTmpl(const TVector3 &p1, const TVector3 &p2) { pMin = p1; pMax = p2; }

  /// Setup a box from center and half side length
  CAABBTmpl(const TVector3 &c, const float s2) 
  {
    pMin.Set(c.x-s2,c.y-s2,c.z-s2);
    pMax.Set(c.x+s2,c.y+s2,c.z+s2);
  }

  void Reset() { pMin.Set(1e20f); pMax.Set(-1e20f); }

  /// Setup a box from center and half side length
  void Set(const TVector3 &c, const float s2) 
  {
    pMin.Set(c.x-s2,c.y-s2,c.z-s2);
    pMax.Set(c.x+s2,c.y+s2,c.z+s2);
  }

  void Set(const TVector3 &p1, const TVector3 &p2) { pMin = p1; pMax = p2; }

  void SafeSet(const TVector3 &p1, const TVector3 &p2)
  {
    pMin = TVector3(min(p1.x, p2.x),min(p1.y, p2.y),min(p1.z, p2.z));
    pMax = TVector3(max(p1.x, p2.x),max(p1.y, p2.y),max(p1.z, p2.z));
  }

  friend inline ostream &operator<<(ostream &os, const CAABBTmpl &b) 
  {
    os << b.pMin << " -> " << b.pMax;
    return os;
  }

  TVector3 Diagonal() const 
  {
    return pMax-pMin;
  }

  void Insert(const TVector3 &p) 
  {
    pMin.Minimize(p);
    pMax.Maximize(p);
  }

  void Insert(const CAABBTmpl& b)
  {
    pMin.Minimize(b.pMin);
    pMax.Maximize(b.pMax);
  }

  inline friend CAABBTmpl Union(const CAABBTmpl &b, const TVector3 &p) 
  {
    CAABBTmpl ret = b;
    ret.pMin.x = min(b.pMin.x, p.x);
    ret.pMin.y = min(b.pMin.y, p.y);
    ret.pMin.z = min(b.pMin.z, p.z);
    ret.pMax.x = max(b.pMax.x, p.x);
    ret.pMax.y = max(b.pMax.y, p.y);
    ret.pMax.z = max(b.pMax.z, p.z);
    return ret;
  }

  inline friend CAABBTmpl Union(const CAABBTmpl &b, const CAABBTmpl &b2) 
  {
    CAABBTmpl ret;
    ret.pMin.x = min(b.pMin.x, b2.pMin.x);
    ret.pMin.y = min(b.pMin.y, b2.pMin.y);
    ret.pMin.z = min(b.pMin.z, b2.pMin.z);
    ret.pMax.x = max(b.pMax.x, b2.pMax.x);
    ret.pMax.y = max(b.pMax.y, b2.pMax.y);
    ret.pMax.z = max(b.pMax.z, b2.pMax.z);
    return ret;
  }

  bool Overlaps(const CAABBTmpl &b) const 
  {
    bool x = (pMax.x >= b.pMin.x) && (pMin.x <= b.pMax.x);
    bool y = (pMax.y >= b.pMin.y) && (pMin.y <= b.pMax.y);
    bool z = (pMax.z >= b.pMin.z) && (pMin.z <= b.pMax.z);
    return (x && y && z);
  }

  bool Contains(const TVector3 &pt) const 
  {
    return 
      pt.x >= pMin.x && pt.x <= pMax.x &&
      pt.y >= pMin.y && pt.y <= pMax.y &&
      pt.z >= pMin.z && pt.z <= pMax.z;
  }

  bool Contains(const CAABBTmpl &b) const 
  {
    return 
      b.pMin.x >= pMin.x && b.pMax.x <= pMax.x &&
      b.pMin.y >= pMin.y && b.pMax.y <= pMax.y &&
      b.pMin.z >= pMin.z && b.pMax.z <= pMax.z;
  }

  void Expand(float delta) 
  {
    pMin -= TVector3(delta, delta, delta);
    pMax += TVector3(delta, delta, delta);
  }

  float Volume() const 
  {
    TVector3 d = pMax - pMin;
    return d.x * d.y * d.z;
  }

  TVector3 Center() const
  {
    return (pMin+pMax)*0.5f;
  }

  int MaxExtentAxis() const 
  {
    TVector3 diag = pMax - pMin;
    if (diag.x > diag.y && diag.x > diag.z)
      return 0;
    else if (diag.y > diag.z)
      return 1;
    else
      return 2;
  }

  void BoundingSphere(TVector3 &c, float &r) const
  {
    c = Center(); 
    r = Distance(c, pMax);
  }

  /// Return true if the given sphere overlaps the box
  inline bool OverlapsSphere(const TVector3& c, const float r) const
  {
    float dmin = 0;
    for( int i = 0; i < 3; i++ ) {
      if      ( c[i] < pMin[i] ) dmin += sqr(c[i] - pMin[i]); 
      else if ( c[i] > pMax[i] ) dmin += sqr(c[i] - pMax[i]);
    }
    return dmin <= r*r;
  }

  /// Return vertex (corner) of an axis aligned box. 
  TVector3 GetVertex(int vidx) const
  {
    return TVector3( 
      (vidx&1) ? pMax.x : pMin.x, 
      (vidx&2) ? pMax.y : pMin.y, 
      (vidx&4) ? pMax.z : pMin.z);
  }

  friend bool operator == (const CAABBTmpl &a, const CAABBTmpl &b)
  { 
    return a.pMin == b.pMin && a.pMax == b.pMax;
  }

  friend bool operator != (const CAABBTmpl &a, const CAABBTmpl &b)
  { 
    return !(a==b);
  }

public:  // CAABBTmpl Public Data
  TVector3 pMin, pMax;
};

#endif // __ICBBOX_H__
