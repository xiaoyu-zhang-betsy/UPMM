// ===================================================================
// $Id: icbase.cpp,v 1.2 2010/02/28 17:33:44 jaroslav Exp $
//
// Initial coding by Jaroslav Krivanek, Nov 2007.

#include "icbase.h"
#include "icrec.h"

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
inline bool
CCachingBase<TRecord>::_mutuallyBehind(const TRecord* r1, const TRecord* r2)
{
  return r1->Behind(r2,TTree::_a) || r2->Behind(r1,TTree::_a);
}

/// recursion depth for neighbor clamping
/** recursion in neighbor clamping turned out to be useless - turned off */
#define IC_NEIGHBOR_CLAMPING_MAX_DEPTH  1

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
void
CCachingBase<TRecord>::_neighborClamping(TRecord* newrec, int recursionDepth)
{
  typename TTree::CTreeLocArray larray; // a local array of fixed size
  larray.clear();

  float unclampedR = newrec->GetUnclampedR();
  const CICVec3& P = newrec->GetP();
  const CICVec3& N = newrec->GetN();
  float sqrDist, distLimit = 0;

  TTree::FindInInfluenceArea(P,N,newrec->GetValidDomain(TTree::_a),larray);

  // reduce this record's radius based on neighbor radii
  if(_clampByNeighbors) {
    for(unsigned i=0; i<larray.size(); i++) {
      const TRecord* rec_i = larray[i].GetObj();

      sqrDist = SqrDistance(rec_i->GetP(), newrec->GetP());

      if( sqr(unclampedR) > sqrDist + sqr(rec_i->GetUnclampedR()) ) {
        distLimit = sqrt(sqrDist) + rec_i->GetUnclampedR();
        distLimit /= DotProd(rec_i->GetN(), newrec->GetN());
        if(unclampedR > distLimit /*&& !_mutuallyBehind( rec_i, newrec)*/ )
          unclampedR = distLimit;
      }

    }
    newrec->SetUnclampedR(unclampedR);
    newrec->SetRClamp(unclampedR);
  }

  // reduce the radii of this record's neighbors
  if(_clampNeighbors) {
    const float sqrUnclampedR = sqr(unclampedR);
    for(unsigned i=0; i<larray.size(); i++) {

      TRecord* rec_i = larray[i].GetObj();
      sqrDist = SqrMagnitude(rec_i->GetP() - newrec->GetP());

      float origUnclampedR_i = rec_i->GetUnclampedR();

      // perform neighbor clamping
      if( sqr(rec_i->GetUnclampedR()) > sqrDist + sqrUnclampedR ) {
        distLimit = sqrt(sqrDist) + unclampedR;
        distLimit /= DotProd(newrec->GetN(),rec_i->GetN());
        if( rec_i->GetUnclampedR() > distLimit /*&& !_mutuallyBehind( rec_i, newrec)*/ )
          rec_i->SetUnclampedR(distLimit);
      }

      // propagate recursively
      if(recursionDepth<IC_NEIGHBOR_CLAMPING_MAX_DEPTH)
        _neighborClamping(rec_i,recursionDepth+1);

      // update position in the tree
      if( rec_i->GetUnclampedR() < origUnclampedR_i ) {
        float R = Clamp(distLimit, rec_i->GetRMinus(), rec_i->GetRPlus() );
        DecreaseRadius(larray[i],R,true/*true = reinsert into tree*/);
      }

    }
  }
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
inline float 
CCachingBase<TRecord>::_visualizationProfile(float sqrNormDist)
{
  return sqrNormDist>4 ? 0 : exp( -sqrNormDist );
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
template<class TRecord>
float
CCachingBase<TRecord>::_visualizeNearestRecords(const CICVec3  &P,
                                                const CICVec3  &N,
                                                const float size) const
{
  typename TTree::CTreeLocArray larray;
  FindInRange(P,N,size*2,larray);

  float size2 = sqr(size);
  float sum = 0;
  for(unsigned i=0; i<larray.size(); i++) {
    const TRecord* rec = larray[i].GetObj();
    float sqrNormDist = SqrDistance(rec->GetP(), P) / size2;
    sum += _visualizationProfile(sqrNormDist);
  }
  return sum;
}

// explicit instantiation of CCachingBase for TRecord=CICRecord
template class CCachingBase<CICRecord>;
