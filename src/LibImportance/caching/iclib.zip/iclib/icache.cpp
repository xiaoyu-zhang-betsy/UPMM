// ===================================================================
// $Id: icache.cpp,v 1.2 2010/02/25 17:51:02 jaroslav Exp $
//
// icache.cpp
//     Implementation of the CICache class.
//     Encapsulation of the irradiance caching and diffuse hemisphere sampling.
//
// Initial coding by Jaroslav Krivanek, Nov 2007.

// ic-lib headers
#include "icache.h"
#include "icsampler.h"
#include "icrec.h"
#include "icbbox.h"

// standard headers
#include <cerrno>
#include <cstdio>
#include <string>

// --------------------------------------------------------------------------
//  CICache::GetIrradiance()
// --------------------------------------------------------------------------
CICache::EQueryResult
CICache::GetIrradiance(const CICVec3    &P,
                       const CICVec3    &N,
                       const CICVec3    &Ng,
                       const float      footprintArea,
                       const void       *shadingGeometry,
					   void             *data,
                       const int        numRays,
                       const int        tid,
                       CICVec3          &outAvgDirL,
                       CICVec3          &outAvgDirR,
                       CICVec3          &outAvgDirG,
                       CICVec3          &outAvgDirB, 
                       float            outE[3])
{
  // initial return value
  EQueryResult retval = EE_Failed;

  // look up the cache
  if(  CICMode::LookIntoCache(GetCachingMode()) ) {
    retval=InterpolateIrradiance(P, N, Ng, tid, outAvgDirL,outAvgDirR,outAvgDirG,outAvgDirB, outE);
  }

  if(retval==EE_Failed) 
  {
	  //std::cout << "sampling hemisphere" << std::endl;
    // no irradiance value found in the cache or no caching
    if( CICMode::SampleHemisphere(GetCachingMode()) ) 
	{
      // sample hemisphere
      retval = AddIrradiance(P,N,Ng,footprintArea,shadingGeometry,numRays,
        outAvgDirL,outAvgDirR,outAvgDirG,outAvgDirB,outE,0,data);
    }
    else 
	{
      // no hemisphere sampling - return black
      setz3(outE);
      outAvgDirL = outAvgDirR = outAvgDirG = outAvgDirB = N;
      retval = EE_Interpolated;
    } 
  }

  // visualize records
  if(_visualizeRecPos) {
    float w = _visualizeNearestRecords(P,N,sqrtf(footprintArea)*_visualRecSize);
    outE += _visualRecColor*w;
  }

  return retval;
}

// --------------------------------------------------------------------------
//  CICache::InterpolateIrradiance()
// --------------------------------------------------------------------------
CICache::EQueryResult
CICache::InterpolateIrradiance(const CICVec3  &P,
                               const CICVec3  &N,
                               const CICVec3  &Ng,
                               const int      tid,
                               CICVec3        &outAvgDirL,
                               CICVec3        &outAvgDirR,
                               CICVec3        &outAvgDirG,
                               CICVec3        &outAvgDirB, 
                               float           outE[3]) const
{
  // find valid irradiance contributions for this position
  CICContribArray carray;
  if (!GetContributions(P,Ng,tid,carray))
    return EE_Failed; // nothing found

  // compute the weighted average of the contributions
  if(carray.size()==1) {
    // only one item - no need to average
    const CICRecord *rec = carray.front().Rec();
    rec->ExtrapolateIrradiance(P,N,outE,_gradsUsed);
    rec->GetAvgDirs(outAvgDirL,outAvgDirR,outAvgDirG,outAvgDirB);
  }
  else {
    // several items - actually compute the average
    float   sumW=0;
    CTriCol sumE(0.0f),cE;
    CICVec3 sumAvgDirL(0), sumAvgDirR(0), sumAvgDirG(0), sumAvgDirB(0);

    for(CICContribArray::const_iterator i=carray.begin(); i!=carray.end(); ++i) 
    {
      const CICRecord *rec = i->Rec();
      rec->ExtrapolateIrradiance(P,N,cE.data(),_gradsUsed);
      sumW += i->w;
      sumE += i->w * cE;
      sumAvgDirL += i->w * rec->GetAvgDirL();
      sumAvgDirR += i->w * rec->GetAvgDirR();
      sumAvgDirG += i->w * rec->GetAvgDirG();
      sumAvgDirB += i->w * rec->GetAvgDirB();
    }

    sumE /= sumW;
    sumE.CopyData(outE);
    outAvgDirL = Normalize(sumAvgDirL);
    outAvgDirR = Normalize(sumAvgDirR);
    outAvgDirG = Normalize(sumAvgDirG);
    outAvgDirB = Normalize(sumAvgDirB);
  }

  return EE_Interpolated;
}

// --------------------------------------------------------------------------
//  CICache::AddIrradiance()
// --------------------------------------------------------------------------
CICache::EQueryResult
CICache::AddIrradiance(const CICVec3 & P,
                       const CICVec3 & N,
                       const CICVec3 & Ng,
                       const float     footprintArea,
                       const void    * shadingGeometry,
                       int             numRays,
                       CICVec3       & outAvgDirL,
                       CICVec3       & outAvgDirR,
                       CICVec3       & outAvgDirG,
                       CICVec3       & outAvgDirB, 
                       float         E[3],
                       CICRecord     ** newRecRet,
					   void          * data)
{
  assert(footprintArea>0);
  assert(CICMode::SampleHemisphere(GetCachingMode()));

  if(newRecRet) *newRecRet = 0;

  float harmMeanDist, minHitDist;

  CICVec3 grads[2*3], *rotGrad, *transGrad;
  memset(grads,0,2*3*sizeof(CICVec3));
  rotGrad   = RotGradUsed()   ? grads   : 0;
  transGrad = TransGradUsed() ? grads+3 : 0;

  // ----------------------------
  //  sample hemisphere
  // ----------------------------
  if( !_icSampler || 
    _icSampler->SampleHemisphere(numRays, shadingGeometry, E, harmMeanDist, minHitDist, 
    outAvgDirL, outAvgDirR, outAvgDirG, outAvgDirB, rotGrad, transGrad, data) == true ) 
  {
    return EE_Failed; // nothing valid stored in E
  }

  // Radius assignment (minHitDist vs. HMD)
  float geomR = _chooseR(minHitDist,harmMeanDist);

  if( !CICMode::InsertIntoCache(GetCachingMode()) ) 
  {
    return EE_NewRecord; // E contains a valid irradiance value
  }

  // ----------------------------
  //  clamp radius by gradients
  // ----------------------------
  float unclampedR = geomR;

  // reduce unclampedR if gradient large
  if(TransGradUsed() && _clampRadiusByGradients) {
    // maximum allowed ratio between upper bound and the actual gradient
    const float gradRatio = IC_USE_MIN_HIT_DIST ? IC_A_RATIO : 1.0f;
    // compute the maximum of gradients over all channels
    float sqrGradMag = 0;
    for(int ch=0; ch<3; ch++) {
      float g = SqrMagnitude(transGrad[ch])/sqr(E[ch]+0.001f);
      if(g > sqrGradMag) sqrGradMag = g;
    }
    // clamp unclampedR if actual gradiant too large
    if ( sqrGradMag * sqr(unclampedR) > sqr(gradRatio) ) {
      unclampedR = gradRatio/sqrt(sqrGradMag);
    }
  }

  // ----------------------------
  //  clamp radius by min/max
  // ----------------------------

  // clamp by minDist/maxDist
  float Rminus,Rplus;
  float pixelSize  = sqrtf(footprintArea);
  _setRminusRplus(Rminus,Rplus, pixelSize);
  float R = Clamp(unclampedR, Rminus, Rplus);

  // ----------------------------
  //  clamp gradients by radius
  // ----------------------------

  // Rectify the gradients if radius enlarged.
  // Greg Ward does this gradient capping by the upper bound derived
  // from the split sphere model (i.e. by E/R), but this test works
  // better.
  if(unclampedR < R && TransGradUsed()) {
    float m = unclampedR / R;
    for(int i=3; i--; ) transGrad[i] *= m;
  }

  // ----------------------------
  //  create new record
  // ----------------------------
  CICRecord *newrec = new CICRecord(P,Ng,R,0?geomR:unclampedR,Rminus,Rplus,
    outAvgDirL, outAvgDirR, outAvgDirG, outAvgDirB, E, grads);
  if(!newrec) return EE_Failed;

  // ----------------------------
  //  neighbor clamping
  //  (a heuristic to rectify some problems near corners)
  // ----------------------------
  if(_clampNeighbors || _clampByNeighbors)
    _neighborClamping(newrec);

  // ----------------------------
  //  insert into cache
  // ----------------------------
  InsertRecord(newrec);

  // ----------------------------
  //  rectify by rot grad
  // ----------------------------
  // Compensates for the difference between N and Ng when Ng is used for hemisphere 
  //  sampling.
  if(RotGradUsed()) {
    CICVec3 nnorm = CrossProd(N, Ng);
    for(int ch=0; ch<3; ch++) {
      E[ch] += DotProd(nnorm, rotGrad[ch]);
    }
  }

  // ----------------------------
  //  visualize record position
  // ----------------------------
  if( _visualizeNewRecPos )
    _visualNewRecColor.CopyData(E); 

  // ----------------------------
  //  return
  // ----------------------------
  if(newRecRet)
    *newRecRet = newrec;

  return EE_NewRecord; // result contains a valid irradiance value
}


// --------------------------------------------------------------------------
//  CICache::RandomizeIrradiances()
// --------------------------------------------------------------------------
void
CICache::RandomizeIrradiances()
{
  CICRecordList &recList = GetRecordList();
  for(CICRecordList::iterator it=recList.begin(); it!=recList.end(); ++it) 
  {
    CTriCol E((*it)->GetE());
    float m = 2*E.Mean();
    if(m==0)
      E.Set(100);
    else {
      E.setz();
      E.Set(rand()%3, m);
    }
    (*it)->SetE(E.data());
  }
}

// --------------------------------------------------------------------------
//  CICache::ReadCache()
// --------------------------------------------------------------------------
bool
CICache::ReadCache()
{
  if(_filename=="")
    return false; // ok - no filename specified

  // check the filemode
  char m = _filemode.c_str()[0];
  if(! (m=='r' || m=='R') )
    return false; // ok - there is no reading

  FILE *f = fopen(_filename.c_str(),"rb");
  if(!f) {
    if(errno ==  ENOENT) return false; // ok if file does not exist
    else 
    {
      std::cerr << "Could not open " << _filename << "for reading." << std::endl;
      return true; // any other reason for failed fopen is an error
    }
  }

  bool ret = ReadCache(f);

  fclose(f);

  _numRecordsRead = GetNumRecords();

  // IC_PRINTVAR(_numRecordsRead);

  return ret;
}

// --------------------------------------------------------------------------
//  CICache::ReadCache()
// --------------------------------------------------------------------------
bool
CICache::ReadCache(FILE *f)
{
  char magic[3];
  size_t numRecords=0;

  if( fread(magic,1,3,f) != 3) 
  {
    std::cerr << "Could not read magic sequence from " << _filename << std::endl;
    return true; // error
  }

  if(strncmp(magic,"AIC",3)!=0)
  {
    std::cerr << "Incorrect magic sequence in " << _filename << std::endl;
    return true; // erorr
  }

  if( fread(&numRecords,sizeof(numRecords),1,f) != 1)
  {
    std::cerr << "Could not read number of records from " << _filename << std::endl;
    return true; // error
  }

  vector<CICRecord*> v(numRecords);

  for(size_t i=0; i<numRecords; i++) 
  {
    // allocate new record
    CICRecord *rec = new CICRecord();
    if(!rec) return true;
    // read the record in
    if(_readRecord(rec, f) == true) 
    { 
      std::cerr << "Could not read record " << i << " from " << _filename << std::endl;
      delete rec; return true; /* error */ 
    }

    v[i] = rec;
  }

  for(size_t i=0; i<numRecords; i++) 
  {
    // insert into spatial index (octree)
    InsertRecord(v[i]);
  }

  return false; // ok
}


// --------------------------------------------------------------------------
//  CICache::WriteCache()
// --------------------------------------------------------------------------
bool
CICache::WriteCache()
{
  if(GetNumRecords()==0)
    return false; // ok - nothing to write

  if(_filename=="")
    return false; // ok - no filename specified

  FILE *f = NULL;
  bool retval = true;

  // check the filemode and decide what to do
  if( _filemode=="w" )
  {
    // try to owerwite the existing file no matter what
    if( (f = fopen(_filename.c_str(),"wb+"))==0 ) return true;
    retval = WriteCache(f);
  }
  else if (_filemode=="rw")
  {
    // try to open an existing file for reading / writing
    f = fopen(_filename.c_str(),"rb+");
    if(!f) 
    {
      // file probably does not exist, try to create a new one and owerwrite
      if( (f = fopen(_filename.c_str(),"wb+"))==0 ) return true;
      retval = WriteCache(f);
    }
    else
    {
      // printf("%s - open in rb+ mode\n",_filename.c_str());

      // file exists and can be read
      char magic[3];
      size_t numRecordsInFile=0;
      long headerSize = 3 + sizeof(size_t);

      // is it a an Arnol Irradiance Cache (AIC) file?
      if(fread(magic,1,3,f) != 3)   goto write_cache_bail_out; // error - cannot read
      if(strncmp(magic,"AIC",3)!=0) goto write_cache_bail_out; // erorr - not an AIC file

      if( fread(&numRecordsInFile,sizeof(numRecordsInFile),1,f) != 1)
        goto write_cache_bail_out; // error - could not read number of records

      // printf("%s - records in file: %d \n",_filename.c_str(),numRecordsInFile);

      // figure out the number of records actually stored in the file
      if( fseek(f, 0, SEEK_END) != 0) return true;
      long currpos = ftell(f);
      if(currpos < 0) return true;
      currpos -= headerSize;

      // IC_PRINTVAR(numRecordsInFile);IC_PRINTVAR(_numRecordsRead);
      // IC_PRINTVAR(currpos);IC_PRINTVAR(numRecordsInFile*sizeof(CICRecord));

      if(numRecordsInFile < _numRecordsRead || 
        (size_t)currpos < numRecordsInFile*sizeof(CICRecord) )
      {
        // printf("%s - owerwriting file contents\n",_filename.c_str());

        // The file contains fewer records than what was read at the cache initialization OR
        // the file contains fewer records than what is indicated in the header.
        // Both situations are abnormal, so let's owerwrite the file with 
        // the contents of this cache.
        if( fseek(f, 0, SEEK_SET) != 0) goto write_cache_bail_out;
        retval = WriteCache(f);
      }
      else
      {
        // everything seems to be ok, so let's add just the newly created records

        // write the new number of records
        if( fseek(f, 3, SEEK_SET) != 0) goto write_cache_bail_out;
        size_t numRecords = numRecordsInFile + GetNumRecords() - _numRecordsRead;
        // IC_PRINTVAR(numRecords);
        if( fwrite(&numRecords,sizeof(numRecords),1,f) != 1) goto write_cache_bail_out;

        // printf("%s - addng %d new records\n",_filename.c_str(),GetNumRecords() - _numRecordsRead);

        if( fseek(f, (long)(headerSize + numRecordsInFile*sizeof(CICRecord)), SEEK_SET) != 0) 
          goto write_cache_bail_out;
        // iterate over the new records in the cache and write them out
        CICRecordList::iterator it = GetRecordList().begin() + _numRecordsRead;
        for(int idx=0; it!=GetRecordList().end(); ++it, ++idx)
        {
          if(_writeRecord( *it , f ) == true) {
            retval = true; // error
            // printf("%s - failed to write record %d\n",_filename.c_str(),idx);
            break;
          }
        }
      }
    }
  }
  else
  {
    // mode is not "w" nor "rw" -> no writing takes place
    return false;
  }

  retval = false; // everything ok

write_cache_bail_out:   
  if(f) fclose(f);
  return retval;
}

// --------------------------------------------------------------------------
//  CICache::WriteCache()
// --------------------------------------------------------------------------
bool
CICache::WriteCache(FILE *f)
{
  const char *magic = "AIC";
  size_t numRecords = GetNumRecords();

  if( fwrite(magic,1,3,f) != 3) 
    return true; // error

  if( fwrite(&numRecords,sizeof(numRecords),1,f) != 1)
    return true;

  // iterate over the records and write them out
  CICRecordList::iterator it = GetRecordList().begin();
  for( ; it!=GetRecordList().end(); ++it)
    if(_writeRecord( *it , f ) == true)
      return true; // error

  return false; // ok
}

// --------------------------------------------------------------------------
//  CICache::_readRecord()
// --------------------------------------------------------------------------
bool 
CICache::_readRecord(CICRecord *rec, FILE *f)
{
  assert(f); assert(rec);

  if( fread(rec,sizeof(CICRecord),1,f) != 1) 
    return true; // erorr

  return false; // ok
}

// --------------------------------------------------------------------------
//  CICache::_writeRecord()
// --------------------------------------------------------------------------
bool
CICache::_writeRecord(const CICRecord *rec, FILE *f)
{
  assert(rec); assert(f);

  if( fwrite(rec,sizeof(CICRecord),1,f) != 1 )
    return true; // error

  return false; // ok
}
