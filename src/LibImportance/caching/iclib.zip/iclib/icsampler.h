// ===================================================================
// $Id: icsampler.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// icsampler.h
//     Header file for the CICSampler class - sampling of the 
//     hemisphere for irradiance caching.
//
// Initial coding by Jaroslav Krivanek, Nov 2007.

#ifndef __ICSAMPLER_H__
#define __ICSAMPLER_H__

// GOLEM headers
#include "icconf.h"
#include "icvec3.h"
#include "tricol.h"

// standard headers
#include <cassert>

/// An abstract class for computing irradiance and irradiance gradients at a point.
/**
This class exists mainly as an interface for the (pure) virtual method 
SampleHemisphere() and possibly also as a storage of some precomputed data
of a particular implementation of the diffuse sampler. The purpose is to
compute irradiance and its gradients at a point through sampling the 
hemisphere of incoming directions. The SampleHemisphere() method is 
called by the irradiance caching algorithm every time interpolation at
a point is impossible.

The hemisphere sampler implementation is te only part of the irradiance
caching code that calls the renderer. The rest of the code is completely 
agnostic of the renderer particularities. 
*/
class CICSampler
{
public: // methods
  
  /// Virtual destructor.
  virtual ~CICSampler() {}
  
  /// Sample hemisphere at a given point.
  /**
    This function is overloaded in the specific 
    implementations of diffuse hemisphere sampling.

    @param numRays          (in)
      Number of rays to use for hemisphere sampling.
    @param shadingGeometry  (in)  
      Hitpoint at which we are to compute the irradiance.
    @param E                (out) 
      Set the resulting irradiance here. Undefined on fail.
    @param harmMeanDist     (out) 
      Harmonic mean of the distances of the hit points.
    @param mitHitDist       (out) 
      Minimum hit point ditance.
    @param rotGrad          (out)
      Rotational gradient for each color band.
    @param transGrad        (out)
      Translational gradient for each color band.
    
    @return  
      'true'  if bailed out for any reason (ie too close to nearby surfaces?)
      'false' on success
	 */
  virtual bool SampleHemisphere(
    int           numRays,
    const void   *shadingGeometry,
    float         E[3],
    float         &harmMeanDist,
    float         &minHitDist,
    CICVec3       &avgDirL,
    CICVec3       &avgDirR,
    CICVec3       &avgDirG,
    CICVec3       &avgDirB,
    CICVec3       *rotGrad,
    CICVec3       *transGrad,
	void          *data) const = 0;
  
  /// Hold data about a hemisphere sample.
  class	CHemiSample {
  public:
    /// Ray direction in the world coordinate frame.
    CICVec3   dir;
    /// Reciprocal of the ray length.
    float	  ir;
    /// Incoming radiance.
    CTriCol   Li;
  };
 
};

/// Base class for diffuse samplers that divide hemisphere into strata in phi/theta.
class CICSamplerStratified : public CICSampler 
{ 
public: // methods
  
  virtual ~CICSamplerStratified() {}

protected: // methods
  
  /// Compute M and N such that M*N approx numRays and N/M approx NoverM.
  static inline void _computeMN(int &M, int &N, int &numRays, float NoverM);
  
  /// Index to the 2d-array of irradiances and hit distances.
  static inline int idx(int j, int k, int M) { return j+k*M; }

  /// The same as idx(), but accepts values outside the [0..M), [0..N) range
  /** Unoptimized - use only for debugging or testing. */
  static inline int idxo(int j, int k, int M, int N) { return (j+M)%M + ((k+N)%N)*M; }

  /// Fill gaps after hemisphere sampling (e.g. when a rays was generated under the geometric tangent plane).
  static void _fillGaps(CHemiSample *hs, int M, int N);

  /// Helper for _fillGaps(): find the next valid hit in the first row.
  static inline int _findValidFwd(const CHemiSample *hs, int M, int begin, int end);

  /// Helper for _fillGaps(): find the previous valid hit in the first row.
  static inline int _findValidBwd(const CHemiSample *hs, int M, int begin, int end);

  /// Helper for _fillGaps(): find the next invalid hit in the first row.
  static inline int _findInvalidFwd(const CHemiSample *hs, int M, int begin, int end);

  /// Helper for _fillGaps(): linear interpolation in the first row.
  static inline void _lintp(CHemiSample *hs, int M, int N, int first, int last);
};

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
void
CICSamplerStratified::_computeMN(int &M, int &N, int &numRays, float NoverM)
{
  if (numRays<=1)
  {
    numRays = M = N  = 1;
  }
  else 
  {
    M = (int)(sqrtf((float)numRays/NoverM));
    if (M < 1) M = 1;
    N = (int)((float)numRays/(float)M);
  }
}


/// Diffuse sampler according to Ward.
/**
  Ward-like diffuse sampler computes the gradients as described
  in the 'Irradiance Gradients' paper (Ward and Heckbert, 1992). 
 */
class CICSamplerWard : public CICSamplerStratified
{
public: // methods
  
  virtual ~CICSamplerWard() {}

protected: // methods
 
  /// Compute rotational gradient - derived from Radiance code - no precomputation.
  static void _rotGradient(CICVec3 *rotGrad, const CHemiSample *hemiSamples, 
    int M, int N, const CICVec3& X, const CICVec3& Y);

  /// Compute translational gradient - derived from Radiance code - no precomputation.
  static void _transGradient(CICVec3 *transGrad, const CHemiSample *hemiSamples, 
    int M, int N, const CICVec3& X, const CICVec3& Y);

  /// Compute irradiance from the hemisphere samples.
  static void _computeIrradiance(float outE[3], const CHemiSample *hemiSamples, 
    int M, int N);

  /** @brief Compute irradiance and average directions for incoming radiance from 
      the hemisphere samples. */
  static void _computeAggregates(
    CICVec3       &outAvgDirL,
    CICVec3       &outAvgDirR,
    CICVec3       &outAvgDirG,
    CICVec3       &outAvgDirB,                       
    float          outE[3], 
    const CHemiSample *hemiSamples,
    int M, int N);

  /// Median-filter the radiance values
  /** Median filtering turned out not to be a very good idea - do not use it. */
  // void _medianFilter(CTriCol *Li) const;
};


#endif // __ICSAMPLER_H__
