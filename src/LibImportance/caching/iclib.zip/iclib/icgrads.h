// ===================================================================
// $Id: icgrads.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// icgrads.h
//      Enums for translational / rotations gradients.
//
// Initial coding by Jaroslav Krivanek, July 2008.

#ifndef __ICGRADS_H__
#define __ICGRADS_H__

/// Codes of gradients are used for interpolation.
enum EGradients
{
  EE_NoGrads   = 0,
  EE_RotGrad   = 1,
  EE_TransGrad = 2,
  EE_AllGrads  = EE_RotGrad|EE_TransGrad,
};

#endif //__ICGRADS_H__
