// ===================================================================
// $Id: fixvec.h,v 1.1 2009/10/20 01:54:17 jaroslav Exp $
//
// fixvec.h
//    Array similar to std::vector() with fixed maximum length.
//
// Class: fixvector
//
// Initial coding by Jaroslav Krivanek, August 2005.

#ifndef __FIXVEC_H__
#define __FIXVEC_H__

/// Array similar to std::vector() with fixed maximum length.
/**
   The length is given as a template parameter.
   If push_back is called and the array is full,
   the fixvec_not_fit() is called with the passed element as
   argument. This function has to be suitably defined, 
   possibly empty.
 */
template<typename _T, unsigned _maxLen>
class fixvector
{
public:
  typedef _T value_type;
  typedef size_t size_type;
  typedef ptrdiff_t difference_type;
  typedef _T* pointer;
  typedef const _T* const_pointer;
  typedef _T& reference;
  typedef const _T& const_reference;

  // begin copy&paste from <vector>
  // class const_iterator;
  // friend class const_iterator;

  class const_iterator
  {	// iterator for nonmutable vector
  public:
    typedef std::random_access_iterator_tag iterator_category;
    typedef _T value_type;
    typedef size_t size_type;
    typedef ptrdiff_t difference_type;
    typedef _T* pointer;
    typedef const _T* const_pointer;
    typedef _T& reference;
    typedef const _T& const_reference;

    typedef pointer _Tptr;
    typedef const_pointer _Ctptr;
    typedef reference _Reft;

    const_iterator()
    {	// construct with null pointer
      _Myptr = 0;
    }

    const_iterator(_Tptr _Ptr)
    {	// construct with pointer _Ptr
      _Myptr = _Ptr;
    }

    const_iterator(_Ctptr _Ptr)
    {	// construct with pointer _Ptr
      _Myptr = (_Tptr)_Ptr;
    }

    const_reference operator*() const
    {	// return designated object
      return (*_Myptr);
    }

    _Ctptr operator->() const
    {	// return pointer to class object
      return (&**this);
    }

    const_iterator& operator++()
    {	// preincrement
      ++_Myptr;
      return (*this);
    }

    const_iterator operator++(int)
    {	// postincrement
      const_iterator _Tmp = *this;
      ++*this;
      return (_Tmp);
    }

    const_iterator& operator--()
    {	// predecrement
      --_Myptr;
      return (*this);
    }

    const_iterator operator--(int)
    {	// postdecrement
      const_iterator _Tmp = *this;
      --*this;
      return (_Tmp);
    }

    const_iterator& operator+=(difference_type _Off)
    {	// increment by integer
      _Myptr += _Off;
      return (*this);
    }

    const_iterator operator+(difference_type _Off) const
    {	// return this + integer
      const_iterator _Tmp = *this;
      return (_Tmp += _Off);
    }

    const_iterator& operator-=(difference_type _Off)
    {	// decrement by integer
      return (*this += -_Off);
    }

    const_iterator operator-(difference_type _Off) const
    {	// return this - integer
      const_iterator _Tmp = *this;
      return (_Tmp -= _Off);
    }

    difference_type operator-(const const_iterator& _Right) const
    {	// return difference of iterators
      return (_Myptr - _Right._Myptr);
    }

    const_reference operator[](difference_type _Off) const
    {	// subscript
      return (*(*this + _Off));
    }

    bool operator==(const const_iterator& _Right) const
    {	// test for iterator equality
      return (_Myptr == _Right._Myptr);
    }

    bool operator!=(const const_iterator& _Right) const
    {	// test for iterator inequality
      return (!(*this == _Right));
    }

    bool operator<(const const_iterator& _Right) const
    {	// test if this < _Right
      return (_Myptr < _Right._Myptr);
    }

    bool operator>(const const_iterator& _Right) const
    {	// test if this > _Right
      return (_Right < *this);
    }

    bool operator<=(const const_iterator& _Right) const
    {	// test if this <= _Right
      return (!(_Right < *this));
    }

    bool operator>=(const const_iterator& _Right) const
    {	// test if this >= _Right
      return (!(*this < _Right));
    }

    friend const_iterator operator+(difference_type _Off,
      const const_iterator& _Right)
    {	// return iterator + integer
      return (_Right + _Off);
    }

    _Tptr _Myptr;	// offset of element in vector
  };

  // CLASS iterator
  class iterator;
  friend class iterator;

	class iterator
		: public const_iterator
		{	// iterator for mutable vector
	public:
		  typedef typename const_iterator::_Tptr _Tptr;


		iterator()
			{	// construct with null vector pointer
			}

		iterator(pointer _Ptr)
			: const_iterator(_Ptr)
			{	// construct with pointer _Ptr
			}

		reference operator*() const
			{	// return designated object
			return ((reference)**(const_iterator *)this);
			}

		_Tptr operator->() const
			{	// return pointer to class object
			return (&**this);
			}

		iterator& operator++()
			{	// preincrement
			++this->_Myptr;
			return (*this);
			}

		iterator operator++(int)
			{	// postincrement
			iterator _Tmp = *this;
			++*this;
			return (_Tmp);
			}

		iterator& operator--()
			{	// predecrement
			--this->_Myptr;
			return (*this);
			}

		iterator operator--(int)
			{	// postdecrement
			iterator _Tmp = *this;
			--*this;
			return (_Tmp);
			}

		iterator& operator+=(difference_type _Off)
			{	// increment by integer
			this->_Myptr += _Off;
			return (*this);
			}

		iterator operator+(difference_type _Off) const
			{	// return this + integer
			iterator _Tmp = *this;
			return (_Tmp += _Off);
			}

		iterator& operator-=(difference_type _Off)
			{	// decrement by integer
			return (*this += -_Off);
			}

		iterator operator-(difference_type _Off) const
			{	// return this - integer
			iterator _Tmp = *this;
			return (_Tmp -= _Off);
			}

		difference_type operator-(const const_iterator& _Right) const
			{	// return difference of iterators
			return ((const_iterator)*this - _Right);
			}

		reference operator[](difference_type _Off) const
			{	// subscript
			return (*(*this + _Off));
			}

		friend iterator operator+(difference_type _Off,
			const iterator& _Right)
			{	// return iterator + integer
			return (_Right + _Off);
			}
		};

  // end copy&paste from <vector>

  fixvector() 
  {
    // _usedItems=0;
    _Mylast = &_array[0];    
  }

  void reserve(unsigned count)
  {
  }

  /// Return the vector capacity. It is the size if the internal vector.
  size_type capacity() const
  {
    return _maxLen;
  }

  /// Return iterator for beginning of nonmutable sequence
	iterator begin()
  {
    return iterator(&_array[0]);
  }

  /// return iterator for beginning of mutable sequence
  const_iterator begin() const
  {
    return const_iterator(&_array[0]);
  }

  /// return iterator for end of mutable sequence
  iterator end()
  {	
    // return begin()+_usedItems;
    return iterator(_Mylast);
  }

  /// return iterator for end of nonmutable sequence
	const_iterator end() const
  {	
    // return begin()+_usedItems;
    return iterator(_Mylast);
  }

  /*
  /// Determine new length, padding with _Ty() elements as needed
  void resize(size_type newsize)
  {
    resize(newsize, _Ty());
  }

  /// Determine new length, padding with _Val elements as needed.
  void resize(size_type newsize, _Ty val)
  {	
    size_type oldvecsize = VT::size();
    if(newsize>oldvecsize)
      VT::resize(newsize,val);
    VT::fill(begin()+_usedItems, begin()+_usedItems-oldvecsize, _Val);
  }
  */

  /// return length of sequence
	size_type size() const
  {
    return end() - begin();
  }

  /// return maximum possible length of sequence
  size_type max_size() const
  {	
    return _maxLen;
  }

  /// test if sequence is empty
  bool empty() const
  {	
    return (size() == 0);
  }

  /// subscript nonmutable sequence
  const_reference operator[](size_type pos) const
  {	
    return _array[pos];
  }

  /// subscript mutable sequence
	reference operator[](size_type pos)
  {
    return _array[pos];
  }

  /// return first element of mutable sequence
	reference front()
  {
    return (*begin());
  }

  /// return first element of nonmutable sequence
  const_reference front() const
  {	
    return (*begin());
  }

  /// return last element of mutable sequence
  reference back()
  {	
    return (*(end() - 1));
  }

  /// return last element of nonmutable sequence
  const_reference back() const
  {	
    return (*(end() - 1));
  }

  /// insert element at end
  void push_back(const _T& val)
  {	
    if(size() < capacity()) {
      *_Mylast++ = val;
    }
    else {
      //fixvec_not_fit(val);
    }
  }

  /// Erase element at end. No deallocation takes place.
  void pop_back()
  {	
    if (!empty())
      _Mylast--;
  }

  /// Erase all. No deallocation takes place.
  void clear()
  {	
    _Mylast = &_array[0];
  }

  /// erase element at where
  iterator erase(iterator where)
  {	
    copy(where+1, end(), where);
    _Mylast--;
    return where;
  }

  /// erase from 'where' to end()
  iterator erase_to_end(iterator where)
  {	
    _Mylast = where;
    return where;
  }

  /// erase [_First, _Last)
  iterator erase(iterator first, iterator last)
  {	
    if(first != last)
    {	// worth doing, copy down over hole
      _Mylast = copy(last, end(), first._Myptr);
    }
    return first;
  }


protected: // data
  /// number of used items in the array
  pointer _Mylast;

  /// array of elements
  value_type _array[_maxLen];
};

#endif // __FIXVEC_H__
